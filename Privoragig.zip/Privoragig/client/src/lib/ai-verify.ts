export interface VerificationResult {
  passed: boolean;
  score: number;
  comment: string;
}

export function aiVerify(text: string): Promise<VerificationResult> {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({
        passed: true,
        score: 92,
        comment: "No plagiarism detected. Structure is clear and original."
      });
    }, 1500);
  });
}
