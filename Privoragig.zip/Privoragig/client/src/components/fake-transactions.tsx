export interface FakeTransaction {
  id: string;
  hash: string;
  type: "task_completion" | "payout" | "stake" | "unstake" | "fee";
  amount: number;
  from: string;
  to: string;
  status: "confirmed" | "pending" | "failed";
  timestamp: number;
  description: string;
}

const taskTitles = [
  "Data Labeling",
  "Image Classification",
  "Sentiment Analysis",
  "Content Research",
  "Transcription",
  "Translation",
  "Document Review",
  "Video Tagging",
  "Web Research",
  "Data Entry",
];

const users = [
  "User#4521",
  "User#3891",
  "User#5021",
  "User#2891",
  "User#3142",
  "User#1823",
  "User#6234",
  "User#7891",
];

function generateWalletHash(): string {
  return `${Math.random().toString(36).substring(2, 10)}...${Math.random().toString(36).substring(2, 10)}`;
}

function generateTransactionHash(): string {
  return Array.from({ length: 44 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
}

export function generateFakeTransaction(): FakeTransaction {
  const typeOptions: FakeTransaction["type"][] = ["task_completion", "payout", "stake", "unstake", "fee"];
  const type = typeOptions[Math.floor(Math.random() * typeOptions.length)];
  const statusOptions: FakeTransaction["status"][] = ["confirmed", "pending", "failed"];
  const status = Math.random() > 0.05 ? "confirmed" : statusOptions[Math.floor(Math.random() * statusOptions.length)];
  
  let amount = 0;
  let description = "";

  switch (type) {
    case "task_completion":
      amount = parseFloat((Math.random() * 0.5 + 0.05).toFixed(2));
      description = `${taskTitles[Math.floor(Math.random() * taskTitles.length)]} Task Reward`;
      break;
    case "payout":
      amount = parseFloat((Math.random() * 1.5 + 0.1).toFixed(2));
      description = "Weekly Payout";
      break;
    case "stake":
      amount = parseFloat((Math.random() * 10 + 1).toFixed(2));
      description = "Staking Deposit";
      break;
    case "unstake":
      amount = parseFloat((Math.random() * 5 + 0.5).toFixed(2));
      description = "Unstaking Withdrawal";
      break;
    case "fee":
      amount = parseFloat((Math.random() * 0.01 + 0.001).toFixed(4));
      description = "Network Fee";
      break;
  }

  return {
    id: `tx_${Date.now()}_${Math.random()}`,
    hash: generateTransactionHash(),
    type,
    amount,
    from: users[Math.floor(Math.random() * users.length)],
    to: users[Math.floor(Math.random() * users.length)],
    status,
    timestamp: Date.now() - Math.floor(Math.random() * 86400000),
    description,
  };
}

export function generateFakeTransactions(count: number = 10): FakeTransaction[] {
  return Array.from({ length: count }, () => generateFakeTransaction());
}

export function streamFakeTransactions(callback: (tx: FakeTransaction) => void, interval: number = 2000): () => void {
  const timer = setInterval(() => {
    callback(generateFakeTransaction());
  }, interval);

  return () => clearInterval(timer);
}
