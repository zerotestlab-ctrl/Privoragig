"use client"

import { useState } from "react"
import { Search, SlidersHorizontal, X, Grid3X3, List } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export type TaskType = "all" | "micro" | "macro"
export type ViewMode = "grid" | "list"

export interface FilterState {
  type: TaskType
  rewardMin: number
  rewardMax: number
  stakeMin: number
  stakeMax: number
  tags: string[]
  search: string
}

interface TaskFilterBarProps {
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
  viewMode: ViewMode
  onViewModeChange: (mode: ViewMode) => void
  availableTags: string[]
}

export function TaskFilterBar({
  filters,
  onFiltersChange,
  viewMode,
  onViewModeChange,
  availableTags,
}: TaskFilterBarProps) {
  const [showFilters, setShowFilters] = useState(false)

  const updateFilter = <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
    onFiltersChange({ ...filters, [key]: value })
  }

  const toggleTag = (tag: string) => {
    const newTags = filters.tags.includes(tag) ? filters.tags.filter((t) => t !== tag) : [...filters.tags, tag]
    updateFilter("tags", newTags)
  }

  const clearFilters = () => {
    onFiltersChange({
      type: "all",
      rewardMin: 0,
      rewardMax: 1000,
      stakeMin: 0,
      stakeMax: 500,
      tags: [],
      search: "",
    })
  }

  const hasActiveFilters =
    filters.type !== "all" ||
    filters.rewardMin > 0 ||
    filters.rewardMax < 1000 ||
    filters.stakeMin > 0 ||
    filters.stakeMax < 500 ||
    filters.tags.length > 0

  return (
    <div className="space-y-4">
      {/* Main filter row */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={filters.search}
            onChange={(e) => updateFilter("search", e.target.value)}
            className="h-10 w-full rounded-lg border border-border bg-secondary/50 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>

        {/* Task type toggle */}
        <div className="flex rounded-lg border border-border bg-secondary/50 p-1">
          {(["all", "micro", "macro"] as TaskType[]).map((type) => (
            <button
              key={type}
              onClick={() => updateFilter("type", type)}
              className={cn(
                "rounded-md px-4 py-1.5 text-sm font-medium transition-colors",
                filters.type === type
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>

        {/* Filter toggle */}
        <Button
          variant={showFilters ? "default" : "outline"}
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
          className={cn("gap-2 rounded-lg", !showFilters && "bg-transparent")}
        >
          <SlidersHorizontal className="h-4 w-4" />
          Filters
          {hasActiveFilters && (
            <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary-foreground text-xs text-primary">
              {(filters.type !== "all" ? 1 : 0) +
                (filters.tags.length > 0 ? 1 : 0) +
                (filters.rewardMin > 0 || filters.rewardMax < 1000 ? 1 : 0) +
                (filters.stakeMin > 0 || filters.stakeMax < 500 ? 1 : 0)}
            </span>
          )}
        </Button>

        {/* View mode toggle */}
        <div className="flex rounded-lg border border-border bg-secondary/50 p-1">
          <button
            onClick={() => onViewModeChange("grid")}
            className={cn(
              "rounded-md p-2 transition-colors",
              viewMode === "grid"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            <Grid3X3 className="h-4 w-4" />
          </button>
          <button
            onClick={() => onViewModeChange("list")}
            className={cn(
              "rounded-md p-2 transition-colors",
              viewMode === "list"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Expanded filters */}
      {showFilters && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex flex-wrap gap-6">
            {/* Reward Range */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Reward Range (SOL)</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={filters.rewardMax}
                  value={filters.rewardMin}
                  onChange={(e) => updateFilter("rewardMin", Number(e.target.value))}
                  className="h-9 w-20 rounded-lg border border-border bg-secondary/50 px-3 text-sm text-foreground focus:border-primary focus:outline-none"
                />
                <span className="text-muted-foreground">-</span>
                <input
                  type="number"
                  min={filters.rewardMin}
                  value={filters.rewardMax}
                  onChange={(e) => updateFilter("rewardMax", Number(e.target.value))}
                  className="h-9 w-20 rounded-lg border border-border bg-secondary/50 px-3 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>
            </div>

            {/* Stake Required Range */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Stake Required (SOL)</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={filters.stakeMax}
                  value={filters.stakeMin}
                  onChange={(e) => updateFilter("stakeMin", Number(e.target.value))}
                  className="h-9 w-20 rounded-lg border border-border bg-secondary/50 px-3 text-sm text-foreground focus:border-primary focus:outline-none"
                />
                <span className="text-muted-foreground">-</span>
                <input
                  type="number"
                  min={filters.stakeMin}
                  value={filters.stakeMax}
                  onChange={(e) => updateFilter("stakeMax", Number(e.target.value))}
                  className="h-9 w-20 rounded-lg border border-border bg-secondary/50 px-3 text-sm text-foreground focus:border-primary focus:outline-none"
                />
              </div>
            </div>

            {/* Skill Tags */}
            <div className="flex-1 min-w-[200px] space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Skill Tags</label>
              <div className="flex flex-wrap gap-1.5">
                {availableTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={cn(
                      "rounded-full px-3 py-1 text-xs font-medium transition-colors",
                      filters.tags.includes(tag)
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80",
                    )}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Clear filters */}
          {hasActiveFilters && (
            <div className="mt-4 flex justify-end border-t border-border pt-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="gap-1.5 text-muted-foreground hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
