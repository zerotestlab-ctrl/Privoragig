"use client"

import { useState } from "react"
import {
  Star,
  Award,
  Trophy,
  Target,
  Shield,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  AlertTriangle,
  ExternalLink,
  Eye,
  EyeOff,
  ThumbsUp,
  Zap,
  Crown,
  Flame,
  Medal,
  ChevronRight,
  Calendar,
  FileText,
  ImageIcon,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"

// Mock user profile data
const userProfile = {
  address: "7xKp...9mNq",
  joinDate: "October 2023",
  privoraScore: 94,
  scoreChange: +2,
  completedTasks: 156,
  successRate: 97.4,
  totalEarnings: 12450.75,
  totalDisputes: 3,
  disputesWon: 2,
  currentStreak: 12,
  bestStreak: 28,
  avgResponseTime: "2.4 hours",
  topCategories: ["Data Labeling", "Image Classification", "Text Analysis"],
}

// Badge definitions
const badges = [
  {
    id: "early_adopter",
    name: "Early Adopter",
    description: "Joined during beta phase",
    icon: Zap,
    color: "text-purple-400",
    bgColor: "bg-purple-400/10",
    borderColor: "border-purple-400/30",
    earned: true,
    earnedDate: "Oct 2023",
  },
  {
    id: "top_performer",
    name: "Top Performer",
    description: "Maintained 95%+ success rate for 30 days",
    icon: Trophy,
    color: "text-yellow-400",
    bgColor: "bg-yellow-400/10",
    borderColor: "border-yellow-400/30",
    earned: true,
    earnedDate: "Dec 2023",
  },
  {
    id: "streak_master",
    name: "Streak Master",
    description: "Completed 25+ tasks in a row without rejection",
    icon: Flame,
    color: "text-orange-400",
    bgColor: "bg-orange-400/10",
    borderColor: "border-orange-400/30",
    earned: true,
    earnedDate: "Jan 2024",
  },
  {
    id: "gold_staker",
    name: "Gold Staker",
    description: "Reached Gold tier staking level",
    icon: Crown,
    color: "text-amber-400",
    bgColor: "bg-amber-400/10",
    borderColor: "border-amber-400/30",
    earned: true,
    earnedDate: "Nov 2023",
  },
  {
    id: "dispute_defender",
    name: "Dispute Defender",
    description: "Won 3 disputes with human review",
    icon: Shield,
    color: "text-slate-400",
    bgColor: "bg-slate-400/10",
    borderColor: "border-slate-400/30",
    earned: false,
    progress: 2,
    target: 3,
  },
  {
    id: "centurion",
    name: "Centurion",
    description: "Completed 100 tasks",
    icon: Medal,
    color: "text-cyan-400",
    bgColor: "bg-cyan-400/10",
    borderColor: "border-cyan-400/30",
    earned: true,
    earnedDate: "Dec 2023",
  },
]

// Dispute history
const disputes = [
  {
    id: 1,
    taskId: "#1234",
    taskTitle: "Data labeling batch - Medical images",
    date: "Jan 10, 2024",
    reason: "AI score disputed - work met all requirements",
    outcome: "won",
    aiScore: 68,
    humanScore: 92,
    amountRecovered: 45.0,
  },
  {
    id: 2,
    taskId: "#1156",
    taskTitle: "Sentiment analysis - Product reviews",
    date: "Dec 28, 2023",
    reason: "Deadline extension not granted despite valid reason",
    outcome: "lost",
    aiScore: 42,
    humanScore: 48,
    amountLost: 7.5,
  },
  {
    id: 3,
    taskId: "#1089",
    taskTitle: "Image classification - Wildlife",
    date: "Dec 15, 2023",
    reason: "Incorrect AI categorization of edge cases",
    outcome: "won",
    aiScore: 71,
    humanScore: 89,
    amountRecovered: 32.0,
  },
]

// Portfolio submissions
const portfolioSubmissions = [
  {
    id: 1,
    taskId: "#1298",
    title: "E-commerce Product Categorization",
    type: "Data Labeling",
    completedDate: "Jan 15, 2024",
    aiScore: 98,
    reward: 125.0,
    thumbnail: "data",
    isPublic: true,
    requesterRating: 5,
  },
  {
    id: 2,
    taskId: "#1287",
    title: "Medical Image Annotation",
    type: "Image Classification",
    completedDate: "Jan 12, 2024",
    aiScore: 96,
    reward: 250.0,
    thumbnail: "image",
    isPublic: true,
    requesterRating: 5,
  },
  {
    id: 3,
    taskId: "#1275",
    title: "Customer Support Sentiment Analysis",
    type: "Text Analysis",
    completedDate: "Jan 8, 2024",
    aiScore: 94,
    reward: 85.0,
    thumbnail: "text",
    isPublic: false,
    requesterRating: 4,
  },
  {
    id: 4,
    taskId: "#1263",
    title: "Social Media Content Moderation",
    type: "Data Labeling",
    completedDate: "Jan 5, 2024",
    aiScore: 97,
    reward: 180.0,
    thumbnail: "data",
    isPublic: true,
    requesterRating: 5,
  },
  {
    id: 5,
    taskId: "#1251",
    title: "Autonomous Vehicle Object Detection",
    type: "Image Classification",
    completedDate: "Jan 2, 2024",
    aiScore: 99,
    reward: 320.0,
    thumbnail: "image",
    isPublic: true,
    requesterRating: 5,
  },
  {
    id: 6,
    taskId: "#1240",
    title: "Legal Document Summarization",
    type: "Text Analysis",
    completedDate: "Dec 28, 2023",
    aiScore: 91,
    reward: 150.0,
    thumbnail: "text",
    isPublic: false,
    requesterRating: 4,
  },
]

export default function ReputationPage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState<"overview" | "portfolio" | "disputes">("overview")
  const [portfolioVisibility, setPortfolioVisibility] = useState<Record<number, boolean>>(
    Object.fromEntries(portfolioSubmissions.map((s) => [s.id, s.isPublic])),
  )

  const toggleVisibility = (id: number) => {
    setPortfolioVisibility((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  // Calculate score ring
  const scorePercent = userProfile.privoraScore
  const circumference = 2 * Math.PI * 54
  const strokeDashoffset = circumference - (scorePercent / 100) * circumference

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={userProfile.address} notificationCount={2} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="Reputation"
        />

        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Profile & Reputation</h1>
              <p className="text-sm text-muted-foreground">Your PrivoraScore, achievements, and public portfolio.</p>
            </div>
            <Button variant="outline" className="gap-2 bg-transparent">
              <ExternalLink className="h-4 w-4" />
              View Public Profile
            </Button>
          </div>

          {/* Profile Header Card */}
          <div className="mb-6 rounded-xl border border-border bg-gradient-to-br from-card to-primary/5 p-6">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-center">
              {/* Score Ring */}
              <div className="relative flex h-36 w-36 shrink-0 items-center justify-center">
                <svg className="h-full w-full -rotate-90" viewBox="0 0 120 120">
                  <circle
                    cx="60"
                    cy="60"
                    r="54"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-secondary"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="54"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    className="text-primary transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold text-foreground">{userProfile.privoraScore}</span>
                  <span className="text-xs text-muted-foreground">PrivoraScore</span>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="flex-1 grid grid-cols-2 gap-4 sm:grid-cols-4">
                <div className="rounded-lg bg-secondary/50 p-3">
                  <div className="mb-1 flex items-center gap-1.5 text-muted-foreground">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span className="text-xs">Completed</span>
                  </div>
                  <p className="text-xl font-bold text-foreground">{userProfile.completedTasks}</p>
                  <p className="text-xs text-muted-foreground">tasks</p>
                </div>

                <div className="rounded-lg bg-secondary/50 p-3">
                  <div className="mb-1 flex items-center gap-1.5 text-muted-foreground">
                    <Target className="h-3.5 w-3.5" />
                    <span className="text-xs">Success Rate</span>
                  </div>
                  <p className="text-xl font-bold text-emerald-500">{userProfile.successRate}%</p>
                  <p className="text-xs text-muted-foreground">accuracy</p>
                </div>

                <div className="rounded-lg bg-secondary/50 p-3">
                  <div className="mb-1 flex items-center gap-1.5 text-muted-foreground">
                    <AlertTriangle className="h-3.5 w-3.5" />
                    <span className="text-xs">Disputes</span>
                  </div>
                  <p className="text-xl font-bold text-foreground">{userProfile.totalDisputes}</p>
                  <p className="text-xs text-emerald-500">{userProfile.disputesWon} won</p>
                </div>

                <div className="rounded-lg bg-secondary/50 p-3">
                  <div className="mb-1 flex items-center gap-1.5 text-muted-foreground">
                    <Flame className="h-3.5 w-3.5" />
                    <span className="text-xs">Streak</span>
                  </div>
                  <p className="text-xl font-bold text-orange-400">{userProfile.currentStreak}</p>
                  <p className="text-xs text-muted-foreground">best: {userProfile.bestStreak}</p>
                </div>
              </div>

              {/* Score Change */}
              <div className="flex flex-col items-center gap-2 rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-1.5">
                  <TrendingUp className="h-4 w-4 text-emerald-500" />
                  <span className="text-sm font-medium text-emerald-500">+{userProfile.scoreChange} pts</span>
                </div>
                <span className="text-xs text-muted-foreground">This month</span>
                <div className="mt-1 text-center">
                  <p className="text-xs text-muted-foreground">Member since</p>
                  <p className="text-sm font-medium text-foreground">{userProfile.joinDate}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mb-6 flex gap-1 rounded-lg bg-secondary p-1">
            {(["overview", "portfolio", "disputes"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 rounded-md px-4 py-2 text-sm font-medium capitalize transition-all ${
                  activeTab === tab
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === "overview" && (
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Badges Section */}
              <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-card-foreground">Badges & Achievements</h2>
                  <span className="text-xs text-muted-foreground">
                    {badges.filter((b) => b.earned).length}/{badges.length} earned
                  </span>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {badges.map((badge) => {
                    const Icon = badge.icon
                    return (
                      <div
                        key={badge.id}
                        className={`relative rounded-lg border p-4 transition-all ${
                          badge.earned
                            ? `${badge.borderColor} ${badge.bgColor}`
                            : "border-border bg-secondary/30 opacity-60"
                        }`}
                      >
                        {badge.earned && <CheckCircle2 className="absolute top-2 right-2 h-4 w-4 text-emerald-500" />}
                        <div className="mb-2 flex items-center gap-2">
                          <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${badge.bgColor}`}>
                            <Icon className={`h-4.5 w-4.5 ${badge.color}`} />
                          </div>
                          <div>
                            <h3
                              className={`text-sm font-semibold ${badge.earned ? badge.color : "text-muted-foreground"}`}
                            >
                              {badge.name}
                            </h3>
                          </div>
                        </div>
                        <p className="mb-2 text-xs text-muted-foreground">{badge.description}</p>
                        {badge.earned ? (
                          <p className="text-[10px] text-muted-foreground">Earned {badge.earnedDate}</p>
                        ) : (
                          <div>
                            <div className="mb-1 flex justify-between text-[10px]">
                              <span className="text-muted-foreground">Progress</span>
                              <span className="text-foreground">
                                {badge.progress}/{badge.target}
                              </span>
                            </div>
                            <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                              <div
                                className="h-full rounded-full bg-primary"
                                style={{ width: `${(badge.progress! / badge.target!) * 100}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Stats Sidebar */}
              <div className="space-y-6">
                {/* Performance Stats */}
                <div className="rounded-xl border border-border bg-card p-5">
                  <h2 className="mb-4 text-lg font-semibold text-card-foreground">Performance</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Avg Response</span>
                      </div>
                      <span className="font-mono text-sm font-medium text-foreground">
                        {userProfile.avgResponseTime}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Total Earned</span>
                      </div>
                      <span className="font-mono text-sm font-medium text-emerald-500">
                        ${userProfile.totalEarnings.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Award className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Dispute Win Rate</span>
                      </div>
                      <span className="font-mono text-sm font-medium text-foreground">
                        {Math.round((userProfile.disputesWon / userProfile.totalDisputes) * 100)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Top Categories */}
                <div className="rounded-xl border border-border bg-card p-5">
                  <h2 className="mb-4 text-lg font-semibold text-card-foreground">Top Categories</h2>
                  <div className="space-y-2">
                    {userProfile.topCategories.map((category, idx) => (
                      <div key={category} className="flex items-center gap-3 rounded-lg bg-secondary/50 px-3 py-2">
                        <span className={`text-sm font-bold ${idx === 0 ? "text-primary" : "text-muted-foreground"}`}>
                          #{idx + 1}
                        </span>
                        <span className="text-sm text-foreground">{category}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "portfolio" && (
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-card-foreground">Public Portfolio</h2>
                  <p className="text-xs text-muted-foreground">Showcase your best work to potential requesters</p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {Object.values(portfolioVisibility).filter(Boolean).length} public
                </span>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {portfolioSubmissions.map((submission) => (
                  <div
                    key={submission.id}
                    className={`rounded-lg border transition-all ${
                      portfolioVisibility[submission.id]
                        ? "border-primary/30 bg-primary/5"
                        : "border-border bg-secondary/30"
                    }`}
                  >
                    {/* Thumbnail */}
                    <div className="relative h-32 rounded-t-lg bg-secondary/50 flex items-center justify-center">
                      {submission.thumbnail === "image" && <ImageIcon className="h-10 w-10 text-muted-foreground/50" />}
                      {submission.thumbnail === "data" && <FileText className="h-10 w-10 text-muted-foreground/50" />}
                      {submission.thumbnail === "text" && <FileText className="h-10 w-10 text-muted-foreground/50" />}
                      <div className="absolute top-2 right-2 flex items-center gap-1 rounded-full bg-background/80 px-2 py-0.5">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs font-medium text-foreground">{submission.aiScore}</span>
                      </div>
                      <button
                        onClick={() => toggleVisibility(submission.id)}
                        className="absolute top-2 left-2 rounded-full bg-background/80 p-1.5 transition-colors hover:bg-background"
                      >
                        {portfolioVisibility[submission.id] ? (
                          <Eye className="h-3.5 w-3.5 text-primary" />
                        ) : (
                          <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                      </button>
                    </div>

                    {/* Content */}
                    <div className="p-4">
                      <div className="mb-2 flex items-start justify-between">
                        <div>
                          <p className="text-xs text-muted-foreground">{submission.taskId}</p>
                          <h3 className="text-sm font-semibold text-foreground line-clamp-1">{submission.title}</h3>
                        </div>
                      </div>

                      <div className="mb-3 flex items-center gap-2">
                        <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                          {submission.type}
                        </span>
                        <div className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-2.5 w-2.5 ${
                                i < submission.requesterRating
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-muted-foreground/30"
                              }`}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {submission.completedDate}
                        </div>
                        <span className="font-mono text-sm font-medium text-emerald-500">
                          +${submission.reward.toFixed(0)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "disputes" && (
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-card-foreground">Dispute History</h2>
                  <p className="text-xs text-muted-foreground">Human review requests and outcomes</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-500">
                    <ThumbsUp className="h-3 w-3" />
                    {userProfile.disputesWon} won
                  </span>
                  <span className="flex items-center gap-1 rounded-full bg-destructive/10 px-2.5 py-1 text-xs font-medium text-destructive">
                    <XCircle className="h-3 w-3" />
                    {userProfile.totalDisputes - userProfile.disputesWon} lost
                  </span>
                </div>
              </div>

              {disputes.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <Shield className="mb-3 h-12 w-12 text-muted-foreground/30" />
                  <p className="text-sm text-muted-foreground">No disputes filed</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {disputes.map((dispute) => (
                    <div
                      key={dispute.id}
                      className={`rounded-lg border p-4 ${
                        dispute.outcome === "won"
                          ? "border-emerald-500/30 bg-emerald-500/5"
                          : "border-destructive/30 bg-destructive/5"
                      }`}
                    >
                      <div className="mb-3 flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-muted-foreground">{dispute.taskId}</span>
                            <h3 className="text-sm font-semibold text-foreground">{dispute.taskTitle}</h3>
                          </div>
                          <p className="mt-1 text-xs text-muted-foreground">{dispute.reason}</p>
                        </div>
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${
                            dispute.outcome === "won"
                              ? "bg-emerald-500/10 text-emerald-500"
                              : "bg-destructive/10 text-destructive"
                          }`}
                        >
                          {dispute.outcome}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">AI Score:</span>
                          <span className="font-mono text-sm text-foreground">{dispute.aiScore}</span>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">Human Score:</span>
                          <span
                            className={`font-mono text-sm font-medium ${
                              dispute.humanScore > dispute.aiScore ? "text-emerald-500" : "text-destructive"
                            }`}
                          >
                            {dispute.humanScore}
                          </span>
                        </div>
                        <div className="ml-auto flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">{dispute.date}</span>
                          {dispute.outcome === "won" ? (
                            <span className="font-mono text-sm font-medium text-emerald-500">
                              +${dispute.amountRecovered?.toFixed(2)} recovered
                            </span>
                          ) : (
                            <span className="font-mono text-sm font-medium text-destructive">
                              -${dispute.amountLost?.toFixed(2)} lost
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
