"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Coins, Lock, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface StakingLevel {
  level: number
  amount: number
  unlocked: boolean
}

interface StakingModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  requiredStake: number
  currentStake: number
  onConfirmStake: (amount: number) => void
  loading?: boolean
}

const stakingLevels: StakingLevel[] = [
  { level: 1, amount: 10, unlocked: true },
  { level: 2, amount: 25, unlocked: true },
  { level: 3, amount: 50, unlocked: false },
  { level: 4, amount: 100, unlocked: false },
  { level: 5, amount: 250, unlocked: false },
]

export function StakingModal({
  open,
  onOpenChange,
  requiredStake,
  currentStake,
  onConfirmStake,
  loading = false,
}: StakingModalProps) {
  const stakeDeficit = requiredStake - currentStake
  const requiredLevel = stakingLevels.find((l) => l.amount >= requiredStake) || stakingLevels[stakingLevels.length - 1]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader className="flex flex-col items-center gap-4 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-chart-3/10">
            <AlertTriangle className="h-7 w-7 text-chart-3" />
          </div>
          <div className="space-y-2">
            <DialogTitle className="text-lg font-semibold text-foreground">Insufficient Stake</DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              This task requires a minimum stake of {requiredStake} SOL. You currently have {currentStake} SOL staked.
            </DialogDescription>
          </div>
        </DialogHeader>

        {/* Stake comparison */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border bg-secondary/30 p-4 text-center">
            <div className="flex items-center justify-center gap-1.5 text-muted-foreground">
              <Coins className="h-4 w-4" />
              <span className="text-xs">Current Stake</span>
            </div>
            <p className="mt-1 font-mono text-xl font-semibold text-foreground">{currentStake} SOL</p>
          </div>
          <div className="rounded-lg border border-primary/50 bg-primary/5 p-4 text-center">
            <div className="flex items-center justify-center gap-1.5 text-primary">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs">Required Stake</span>
            </div>
            <p className="mt-1 font-mono text-xl font-semibold text-primary">{requiredStake} SOL</p>
          </div>
        </div>

        {/* Stake levels */}
        <div className="mt-4">
          <p className="mb-3 text-xs font-medium text-muted-foreground">Staking Levels</p>
          <div className="flex gap-2">
            {stakingLevels.map((level) => {
              const isRequired =
                level.amount >= requiredStake &&
                stakingLevels.find((l) => l.amount >= requiredStake)?.level === level.level
              const isCurrent = currentStake >= level.amount

              return (
                <div
                  key={level.level}
                  className={cn(
                    "relative flex flex-1 flex-col items-center rounded-lg border p-2 transition-all",
                    isRequired
                      ? "border-primary bg-primary/10"
                      : isCurrent
                        ? "border-chart-3/50 bg-chart-3/5"
                        : "border-border bg-secondary/30",
                  )}
                >
                  {!isCurrent && !isRequired && (
                    <Lock className="absolute -top-1.5 -right-1.5 h-3.5 w-3.5 text-muted-foreground" />
                  )}
                  <span
                    className={cn(
                      "text-[10px] font-medium",
                      isRequired ? "text-primary" : isCurrent ? "text-chart-3" : "text-muted-foreground",
                    )}
                  >
                    Lvl {level.level}
                  </span>
                  <span
                    className={cn(
                      "font-mono text-sm font-semibold",
                      isRequired ? "text-primary" : isCurrent ? "text-chart-3" : "text-foreground",
                    )}
                  >
                    {level.amount}
                  </span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Stake deficit notice */}
        <div className="mt-4 rounded-lg border border-chart-3/30 bg-chart-3/5 p-3">
          <p className="text-center text-sm text-chart-3">
            You need to stake an additional <span className="font-mono font-semibold">{stakeDeficit} SOL</span> to take
            this task.
          </p>
        </div>

        <DialogFooter className="mt-6 flex gap-3 sm:justify-center">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
            className="flex-1 rounded-lg bg-transparent sm:flex-none"
          >
            Cancel
          </Button>
          <Button
            variant="default"
            onClick={() => onConfirmStake(stakeDeficit)}
            disabled={loading}
            className="flex-1 rounded-lg sm:flex-none"
          >
            {loading ? "Staking..." : `Stake ${stakeDeficit} SOL`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
