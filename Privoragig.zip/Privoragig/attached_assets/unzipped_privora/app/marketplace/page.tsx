"use client"

import { useState, useMemo } from "react"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { TaskCard, type Task } from "@/components/task-card"
import { TaskFilterBar, type FilterState, type ViewMode } from "@/components/task-filter-bar"
import { ConfirmationModal } from "@/components/confirmation-modal"
import { Bot, Clock, Coins, Star, User } from "lucide-react"
import { cn } from "@/lib/utils"

// Mock task data
const mockTasks: Task[] = [
  {
    id: "1",
    title: "Label 500 Product Images",
    description: "Classify e-commerce product images into 20 predefined categories for training data.",
    type: "micro",
    reward: 25,
    stakeRequired: 10,
    eta: "2h",
    tags: ["Data Labeling", "Images", "E-commerce"],
    aiRequired: false,
    requesterRating: 4.8,
    requesterName: "DataCorp",
  },
  {
    id: "2",
    title: "Sentiment Analysis Model Training",
    description: "Fine-tune a sentiment analysis model on customer reviews dataset with 10k samples.",
    type: "macro",
    reward: 150,
    stakeRequired: 75,
    eta: "48h",
    tags: ["ML", "NLP", "Training"],
    aiRequired: true,
    requesterRating: 4.9,
    requesterName: "AI Labs",
  },
  {
    id: "3",
    title: "Transcribe 100 Audio Clips",
    description: "Convert short audio recordings to text with speaker identification and timestamps.",
    type: "micro",
    reward: 35,
    stakeRequired: 15,
    eta: "4h",
    tags: ["Audio", "Transcription"],
    aiRequired: false,
    requesterRating: 4.5,
    requesterName: "MediaPro",
  },
  {
    id: "4",
    title: "Build RAG Pipeline",
    description: "Create a retrieval-augmented generation system for technical documentation search.",
    type: "macro",
    reward: 200,
    stakeRequired: 100,
    eta: "72h",
    tags: ["ML", "RAG", "LLM", "Backend"],
    aiRequired: true,
    requesterRating: 4.7,
    requesterName: "TechDocs Inc",
  },
  {
    id: "5",
    title: "Validate Address Data",
    description: "Verify and correct shipping addresses against postal database for accuracy.",
    type: "micro",
    reward: 18,
    stakeRequired: 5,
    eta: "1h",
    tags: ["Data Validation", "QA"],
    aiRequired: false,
    requesterRating: 4.3,
    requesterName: "ShipFast",
  },
  {
    id: "6",
    title: "Train Object Detection Model",
    description: "Train YOLOv8 model on custom dataset for detecting manufacturing defects.",
    type: "macro",
    reward: 180,
    stakeRequired: 90,
    eta: "60h",
    tags: ["ML", "Computer Vision", "Training"],
    aiRequired: true,
    requesterRating: 4.6,
    requesterName: "ManufacturAI",
  },
  {
    id: "7",
    title: "Categorize Support Tickets",
    description: "Sort and tag customer support tickets by issue type and priority level.",
    type: "micro",
    reward: 22,
    stakeRequired: 8,
    eta: "3h",
    tags: ["Data Labeling", "Support", "Text"],
    aiRequired: false,
    requesterRating: 4.4,
    requesterName: "HelpDesk Co",
  },
  {
    id: "8",
    title: "Fine-tune Code Assistant",
    description: "Adapt an open-source LLM for code completion in Solana/Rust development.",
    type: "macro",
    reward: 250,
    stakeRequired: 125,
    eta: "96h",
    tags: ["ML", "LLM", "Solana", "Fine-tuning"],
    aiRequired: true,
    requesterRating: 5.0,
    requesterName: "DevTools DAO",
  },
]

const availableTags = [
  "Data Labeling",
  "ML",
  "NLP",
  "Computer Vision",
  "LLM",
  "Audio",
  "Images",
  "Text",
  "Training",
  "Fine-tuning",
  "RAG",
  "Backend",
  "Solana",
]

export default function MarketplacePage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>("grid")
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [showConfirmModal, setShowConfirmModal] = useState(false)

  const [filters, setFilters] = useState<FilterState>({
    type: "all",
    rewardMin: 0,
    rewardMax: 1000,
    stakeMin: 0,
    stakeMax: 500,
    tags: [],
    search: "",
  })

  const filteredTasks = useMemo(() => {
    return mockTasks.filter((task) => {
      // Type filter
      if (filters.type !== "all" && task.type !== filters.type) return false

      // Reward range
      if (task.reward < filters.rewardMin || task.reward > filters.rewardMax) return false

      // Stake range
      if (task.stakeRequired < filters.stakeMin || task.stakeRequired > filters.stakeMax) return false

      // Tags filter
      if (filters.tags.length > 0 && !filters.tags.some((tag) => task.tags.includes(tag))) return false

      // Search
      if (filters.search) {
        const search = filters.search.toLowerCase()
        if (
          !task.title.toLowerCase().includes(search) &&
          !task.description.toLowerCase().includes(search) &&
          !task.tags.some((tag) => tag.toLowerCase().includes(search))
        )
          return false
      }

      return true
    })
  }, [filters])

  const handleTakeTask = (task: Task) => {
    setSelectedTask(task)
    setShowConfirmModal(true)
  }

  const handleConfirmTake = () => {
    // Handle task acceptance logic here
    setShowConfirmModal(false)
    setSelectedTask(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={3} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="Marketplace"
        />

        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground">Task Marketplace</h1>
            <p className="text-sm text-muted-foreground">
              Browse and take available tasks. {filteredTasks.length} tasks found.
            </p>
          </div>

          {/* Filter Bar */}
          <div className="mb-6">
            <TaskFilterBar
              filters={filters}
              onFiltersChange={setFilters}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              availableTags={availableTags}
            />
          </div>

          {/* Task Grid/List */}
          {filteredTasks.length > 0 ? (
            <div
              className={cn(
                viewMode === "grid" ? "grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" : "space-y-3",
              )}
            >
              {filteredTasks.map((task) =>
                viewMode === "grid" ? (
                  <TaskCard key={task.id} task={task} onTake={handleTakeTask} />
                ) : (
                  // List view variant
                  <div
                    key={task.id}
                    className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/50"
                  >
                    {/* Type badge */}
                    <span
                      className={cn(
                        "shrink-0 rounded-md px-2.5 py-1 text-xs font-medium",
                        task.type === "micro" ? "bg-primary/10 text-primary" : "bg-chart-3/10 text-chart-3",
                      )}
                    >
                      {task.type === "micro" ? "Micro" : "Macro"}
                    </span>

                    {/* Main content */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="truncate text-sm font-semibold text-card-foreground">{task.title}</h3>
                        {task.aiRequired && <Bot className="h-4 w-4 shrink-0 text-primary" />}
                      </div>
                      <p className="truncate text-xs text-muted-foreground">{task.description}</p>
                    </div>

                    {/* Stats */}
                    <div className="hidden shrink-0 items-center gap-4 md:flex">
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-primary">
                          <Coins className="h-3.5 w-3.5" />
                          <span className="font-mono text-sm font-semibold">{task.reward}</span>
                        </div>
                        <span className="text-[10px] text-muted-foreground">Reward</span>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-chart-3">
                          <Coins className="h-3.5 w-3.5" />
                          <span className="font-mono text-sm font-semibold">{task.stakeRequired}</span>
                        </div>
                        <span className="text-[10px] text-muted-foreground">Stake</span>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Clock className="h-3.5 w-3.5" />
                          <span className="text-sm font-medium">{task.eta}</span>
                        </div>
                        <span className="text-[10px] text-muted-foreground">ETA</span>
                      </div>
                    </div>

                    {/* Requester */}
                    <div className="hidden shrink-0 items-center gap-2 lg:flex">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary">
                        <User className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">{task.requesterName}</p>
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-chart-3 text-chart-3" />
                          <span className="text-xs font-medium text-card-foreground">
                            {task.requesterRating.toFixed(1)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Take button */}
                    <button
                      onClick={() => handleTakeTask(task)}
                      className="shrink-0 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                    >
                      Take
                    </button>
                  </div>
                ),
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 py-16">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-secondary">
                <Coins className="h-7 w-7 text-muted-foreground" />
              </div>
              <h3 className="mb-1 text-lg font-medium text-card-foreground">No tasks found</h3>
              <p className="text-sm text-muted-foreground">Try adjusting your filters to see more results.</p>
            </div>
          )}
        </main>
      </div>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        onConfirm={handleConfirmTake}
        title="Take This Task?"
        description={
          selectedTask
            ? `You're about to accept "${selectedTask.title}". This will require staking ${selectedTask.stakeRequired} SOL. The estimated time is ${selectedTask.eta}.`
            : ""
        }
        confirmLabel="Confirm & Stake"
        cancelLabel="Cancel"
        variant="info"
      />
    </div>
  )
}
