import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download } from "lucide-react";
import MotionDiv from "@/components/motion-div";

export default function Whitepaper() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <MotionDiv>
          <Button 
            variant="ghost" 
            className="mb-8 gap-2 pl-0 hover:pl-2 transition-all"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </MotionDiv>

        <MotionDiv delay={0.1}>
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-card-foreground mb-4">
              Privora Whitepaper
            </h1>
            <p className="text-lg text-muted-foreground">
              A Solana-native task marketplace with AI verification and staking-based quality control
            </p>
          </div>
        </MotionDiv>

        <MotionDiv delay={0.2}>
          <div className="grid gap-6 md:grid-cols-2 mb-12">
            <div className="p-6 rounded-xl border border-border bg-card">
              <h3 className="font-semibold text-card-foreground mb-2">Published</h3>
              <p className="text-muted-foreground">December 2, 2025</p>
            </div>
            <div className="p-6 rounded-xl border border-border bg-card">
              <h3 className="font-semibold text-card-foreground mb-2">Version</h3>
              <p className="text-muted-foreground">v1.0 Alpha</p>
            </div>
          </div>
        </MotionDiv>

        <MotionDiv delay={0.3}>
          <div className="prose prose-invert max-w-none mb-12 space-y-8">
            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                Privora is a decentralized task marketplace built on Solana that revolutionizes how work is verified and compensated. By combining AI-powered quality verification with blockchain-based staking mechanisms, Privora creates a transparent, trustless ecosystem where high-quality work is rewarded instantly in SOL.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Key Features</h2>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex gap-3">
                  <span className="text-primary">✓</span>
                  <span><strong>AI Verification:</strong> Advanced AI agents automatically verify task quality and provide detailed feedback scores</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary">✓</span>
                  <span><strong>Staking Collateral:</strong> Workers stake SOL to build reputation and unlock premium task opportunities</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary">✓</span>
                  <span><strong>Instant Payouts:</strong> Verified completions receive immediate SOL rewards on the Solana blockchain</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary">✓</span>
                  <span><strong>Reputation System:</strong> Dynamic scoring based on completion rate, quality, and community feedback</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary">✓</span>
                  <span><strong>Dispute Resolution:</strong> Decentralized dispute mechanism with community arbitration</span>
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Market Opportunity</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The global freelance and task-based work market exceeds $3 trillion annually. Current platforms suffer from:
              </p>
              <ul className="space-y-2 text-muted-foreground ml-4">
                <li>• High platform fees (20-30%)</li>
                <li>• Slow payment processing (weeks)</li>
                <li>• Centralized quality control bottlenecks</li>
                <li>• Geographic payment restrictions</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Privora addresses these limitations by leveraging Solana's speed, low costs, and decentralized infrastructure.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">How It Works</h2>
              <div className="bg-secondary/50 p-6 rounded-lg space-y-4">
                <div>
                  <h3 className="font-semibold text-card-foreground mb-2">1. Task Creation</h3>
                  <p className="text-muted-foreground text-sm">Users post tasks with detailed descriptions, reward amounts, and staking requirements</p>
                </div>
                <div>
                  <h3 className="font-semibold text-card-foreground mb-2">2. Worker Submission</h3>
                  <p className="text-muted-foreground text-sm">Workers stake collateral and submit their work for review</p>
                </div>
                <div>
                  <h3 className="font-semibold text-card-foreground mb-2">3. AI Verification</h3>
                  <p className="text-muted-foreground text-sm">Advanced AI evaluates quality, plagiarism, and task compliance automatically</p>
                </div>
                <div>
                  <h3 className="font-semibold text-card-foreground mb-2">4. Instant Payout</h3>
                  <p className="text-muted-foreground text-sm">Upon verification pass, workers receive SOL rewards immediately on Solana</p>
                </div>
                <div>
                  <h3 className="font-semibold text-card-foreground mb-2">5. Reputation Update</h3>
                  <p className="text-muted-foreground text-sm">Completion and quality score update worker reputation and unlock higher-tier tasks</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Tokenomics</h2>
              <p className="text-muted-foreground leading-relaxed">
                Privora operates entirely on Solana (SOL). No native token is required for v1. This approach ensures:
              </p>
              <ul className="space-y-2 text-muted-foreground ml-4 mt-3">
                <li>• Immediate usability with existing infrastructure</li>
                <li>• No speculative token dynamics</li>
                <li>• Direct SOL value capture for workers</li>
                <li>• Future governance token (PRV) planned for v2</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Roadmap</h2>
              <div className="space-y-3">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <h3 className="font-semibold text-card-foreground mb-1">Phase 1 (Q4 2025)</h3>
                  <p className="text-sm text-muted-foreground">Alpha launch with core marketplace and AI verification</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                  <h3 className="font-semibold text-card-foreground mb-1">Phase 2 (Q1 2026)</h3>
                  <p className="text-sm text-muted-foreground">Community governance, dispute resolution, and staking rewards</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                  <h3 className="font-semibold text-card-foreground mb-1">Phase 3 (Q2 2026)</h3>
                  <p className="text-sm text-muted-foreground">PRV token launch, mobile app, and advanced analytics</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-card-foreground mb-4">Get Started</h2>
              <p className="text-muted-foreground leading-relaxed">
                Join Privora today by connecting your Phantom wallet or using our Mock Wallet. Browse tasks, submit work, and start earning SOL immediately with our AI-powered verification system.
              </p>
            </section>
          </div>
        </MotionDiv>

        <MotionDiv delay={0.4}>
          <div className="flex flex-col sm:flex-row gap-4 pt-8 border-t border-border">
            <Button className="gap-2">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
            <Button variant="outline" onClick={() => setLocation("/")}>
              Return Home
            </Button>
          </div>
        </MotionDiv>
      </div>
    </div>
  );
}
