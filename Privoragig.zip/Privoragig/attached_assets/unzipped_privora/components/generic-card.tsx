"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface GenericCardProps {
  title: string
  subtitle?: string
  children?: React.ReactNode
  actionLabel?: string
  onAction?: () => void
  actionVariant?: "default" | "outline" | "secondary" | "ghost" | "destructive"
  className?: string
  headerAction?: React.ReactNode
}

export function GenericCard({
  title,
  subtitle,
  children,
  actionLabel,
  onAction,
  actionVariant = "default",
  className,
  headerAction,
}: GenericCardProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-border bg-card p-6 shadow-sm transition-shadow hover:shadow-md",
        className,
      )}
    >
      {/* Header */}
      <div className="mb-4 flex items-start justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-lg font-semibold text-card-foreground">{title}</h3>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
        {headerAction && <div>{headerAction}</div>}
      </div>

      {/* Body */}
      {children && <div className="mb-4 text-card-foreground">{children}</div>}

      {/* Action Button */}
      {actionLabel && (
        <Button variant={actionVariant} onClick={onAction} className="w-full rounded-lg">
          {actionLabel}
        </Button>
      )}
    </div>
  )
}
