"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { ConfirmationModal } from "@/components/confirmation-modal"
import { StakingModal } from "@/components/staking-modal"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import {
  ArrowLeft,
  Bot,
  Calendar,
  Clock,
  Coins,
  FileUp,
  MessageSquare,
  Send,
  Star,
  Upload,
  User,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import { cn } from "@/lib/utils"

// Mock task data
const mockTask = {
  id: "1",
  title: "Label 500 Product Images",
  description:
    "Classify e-commerce product images into 20 predefined categories for training data. Each image should be labeled with the primary category and up to 3 secondary tags. Quality verification will be done through AI cross-checking.",
  fullDescription: `## Task Overview
This task involves categorizing product images from our e-commerce catalog. You'll be working with a dataset of 500 images that need accurate labeling for our machine learning training pipeline.

## Requirements
- Label each image with one primary category from the provided list
- Add up to 3 relevant secondary tags
- Flag any images that are unclear or damaged
- Maintain at least 95% accuracy (verified by AI)

## Categories
Electronics, Clothing, Home & Garden, Sports, Books, Toys, Beauty, Food, Automotive, Other

## Deliverables
- JSON file with image IDs and corresponding labels
- Summary report of any flagged images`,
  type: "micro" as const,
  reward: 25,
  stakeRequired: 50,
  eta: "2h",
  deadline: "2024-12-15T18:00:00Z",
  tags: ["Data Labeling", "Images", "E-commerce"],
  aiRequired: false,
  requesterRating: 4.8,
  requesterName: "DataCorp",
  requesterAddress: "7xKp...9mNq",
  status: "open" as const,
  submissionsCount: 3,
  discussionCount: 12,
}

// Mock submissions
const mockSubmissions = [
  {
    id: "s1",
    workerName: "Alice",
    workerAddress: "8yLq...4pRs",
    submittedAt: "2024-12-10T14:30:00Z",
    status: "pending" as const,
    preview: "labels_batch_1.json",
  },
  {
    id: "s2",
    workerName: "Bob",
    workerAddress: "3zMn...7tUv",
    submittedAt: "2024-12-09T10:15:00Z",
    status: "approved" as const,
    preview: "complete_labels.json",
  },
  {
    id: "s3",
    workerName: "Carol",
    workerAddress: "5wOx...2qWy",
    submittedAt: "2024-12-08T16:45:00Z",
    status: "rejected" as const,
    preview: "image_categories.json",
  },
]

// Mock discussion
const mockDiscussion = [
  {
    id: "d1",
    author: "DataCorp",
    authorAddress: "7xKp...9mNq",
    isRequester: true,
    message: "Please make sure to use the exact category names from the provided list. Case sensitivity matters!",
    timestamp: "2024-12-08T09:00:00Z",
  },
  {
    id: "d2",
    author: "Alice",
    authorAddress: "8yLq...4pRs",
    isRequester: false,
    message: "What should we do with images that show multiple products?",
    timestamp: "2024-12-08T11:30:00Z",
  },
  {
    id: "d3",
    author: "DataCorp",
    authorAddress: "7xKp...9mNq",
    isRequester: true,
    message: "Great question! Use the category of the main/largest product and add others as secondary tags.",
    timestamp: "2024-12-08T12:15:00Z",
  },
]

type TabType = "overview" | "submissions" | "discussion"

export default function TaskDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState<TabType>("overview")
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false)
  const [showStakingModal, setShowStakingModal] = useState(false)
  const [submissionText, setSubmissionText] = useState("")
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [discussionMessage, setDiscussionMessage] = useState("")

  // Mock user state
  const currentUserStake = 25 // User has 25 SOL staked
  const needsMoreStake = currentUserStake < mockTask.stakeRequired

  const handleTakeTask = () => {
    if (needsMoreStake) {
      setShowStakingModal(true)
    } else {
      // Proceed with taking the task
    }
  }

  const handleSubmit = () => {
    if (submissionText || uploadedFile) {
      setShowSubmitConfirm(true)
    }
  }

  const handleConfirmSubmit = () => {
    // Handle submission logic
    setShowSubmitConfirm(false)
    setSubmissionText("")
    setUploadedFile(null)
  }

  const handleStakeConfirm = (amount: number) => {
    // Handle staking logic
    setShowStakingModal(false)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const tabs: { id: TabType; label: string; count?: number }[] = [
    { id: "overview", label: "Overview" },
    { id: "submissions", label: "Submissions", count: mockTask.submissionsCount },
    { id: "discussion", label: "Discussion", count: mockTask.discussionCount },
  ]

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={3} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="Marketplace"
        />

        <main className="flex-1 p-6">
          {/* Back button */}
          <button
            onClick={() => router.back()}
            className="mb-4 flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Marketplace
          </button>

          {/* Task Header */}
          <div className="mb-6 rounded-xl border border-border bg-card p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              {/* Left: Title and meta */}
              <div className="flex-1">
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <span
                    className={cn(
                      "rounded-md px-2.5 py-1 text-xs font-medium",
                      mockTask.type === "micro" ? "bg-primary/10 text-primary" : "bg-chart-3/10 text-chart-3",
                    )}
                  >
                    {mockTask.type === "micro" ? "Micro Task" : "Macro Task"}
                  </span>
                  {mockTask.aiRequired && (
                    <div className="flex items-center gap-1.5 rounded-md bg-secondary px-2 py-1">
                      <Bot className="h-3.5 w-3.5 text-primary" />
                      <span className="text-xs text-muted-foreground">AI Verification</span>
                    </div>
                  )}
                  <span className="rounded-md bg-chart-3/10 px-2.5 py-1 text-xs font-medium text-chart-3">Open</span>
                </div>
                <h1 className="mb-2 text-2xl font-semibold text-foreground">{mockTask.title}</h1>
                <p className="text-sm text-muted-foreground">{mockTask.description}</p>

                {/* Tags */}
                <div className="mt-4 flex flex-wrap gap-2">
                  {mockTask.tags.map((tag) => (
                    <span key={tag} className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Right: Stats and actions */}
              <div className="flex flex-col gap-4 lg:items-end">
                {/* Stats grid */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2">
                  <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-primary">
                      <Coins className="h-4 w-4" />
                      <span className="font-mono text-lg font-semibold">{mockTask.reward}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">USDC Reward</span>
                  </div>
                  <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-chart-3">
                      <Coins className="h-4 w-4" />
                      <span className="font-mono text-lg font-semibold">{mockTask.stakeRequired}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">SOL Stake Req.</span>
                  </div>
                  <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span className="text-lg font-semibold">{mockTask.eta}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">Est. Time</span>
                  </div>
                  <div className="rounded-lg border border-border bg-secondary/30 p-3 text-center">
                    <div className="flex items-center justify-center gap-1.5 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span className="text-sm font-semibold">Dec 15</span>
                    </div>
                    <span className="text-xs text-muted-foreground">Deadline</span>
                  </div>
                </div>

                {/* Requester info */}
                <div className="flex items-center gap-3 rounded-lg border border-border bg-secondary/30 px-4 py-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                    <User className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{mockTask.requesterName}</p>
                    <p className="text-xs text-muted-foreground">{mockTask.requesterAddress}</p>
                  </div>
                  <div className="ml-2 flex items-center gap-1">
                    <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                    <span className="text-sm font-medium text-foreground">{mockTask.requesterRating}</span>
                  </div>
                </div>

                {/* Take task button */}
                <Button onClick={handleTakeTask} className="w-full rounded-lg lg:w-auto">
                  {needsMoreStake ? "Stake & Take Task" : "Take Task"}
                </Button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mb-6 border-b border-border">
            <div className="flex gap-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "relative flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors",
                    activeTab === tab.id ? "text-primary" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {tab.label}
                  {tab.count !== undefined && (
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-xs",
                        activeTab === tab.id ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground",
                      )}
                    >
                      {tab.count}
                    </span>
                  )}
                  {activeTab === tab.id && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Main content area */}
            <div className="lg:col-span-2">
              {activeTab === "overview" && (
                <div className="rounded-xl border border-border bg-card p-6">
                  <h2 className="mb-4 text-lg font-semibold text-foreground">Task Details</h2>
                  <div className="prose prose-sm prose-invert max-w-none">
                    <div className="space-y-4 text-sm text-muted-foreground">
                      <div>
                        <h3 className="mb-2 text-base font-medium text-foreground">Task Overview</h3>
                        <p>
                          This task involves categorizing product images from our e-commerce catalog. You'll be working
                          with a dataset of 500 images that need accurate labeling for our machine learning training
                          pipeline.
                        </p>
                      </div>
                      <div>
                        <h3 className="mb-2 text-base font-medium text-foreground">Requirements</h3>
                        <ul className="list-disc space-y-1 pl-4">
                          <li>Label each image with one primary category from the provided list</li>
                          <li>Add up to 3 relevant secondary tags</li>
                          <li>Flag any images that are unclear or damaged</li>
                          <li>Maintain at least 95% accuracy (verified by AI)</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="mb-2 text-base font-medium text-foreground">Categories</h3>
                        <p>
                          Electronics, Clothing, Home & Garden, Sports, Books, Toys, Beauty, Food, Automotive, Other
                        </p>
                      </div>
                      <div>
                        <h3 className="mb-2 text-base font-medium text-foreground">Deliverables</h3>
                        <ul className="list-disc space-y-1 pl-4">
                          <li>JSON file with image IDs and corresponding labels</li>
                          <li>Summary report of any flagged images</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "submissions" && (
                <div className="space-y-4">
                  {mockSubmissions.map((submission) => (
                    <div
                      key={submission.id}
                      className="flex items-center gap-4 rounded-xl border border-border bg-card p-4"
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                        <User className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-foreground">{submission.workerName}</span>
                          <span className="text-xs text-muted-foreground">{submission.workerAddress}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <FileUp className="h-3.5 w-3.5" />
                          <span>{submission.preview}</span>
                          <span>•</span>
                          <span>{formatDate(submission.submittedAt)}</span>
                        </div>
                      </div>
                      <span
                        className={cn(
                          "flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium",
                          submission.status === "approved"
                            ? "bg-primary/10 text-primary"
                            : submission.status === "rejected"
                              ? "bg-destructive/10 text-destructive"
                              : "bg-chart-3/10 text-chart-3",
                        )}
                      >
                        {submission.status === "approved" ? (
                          <CheckCircle className="h-3.5 w-3.5" />
                        ) : submission.status === "rejected" ? (
                          <AlertCircle className="h-3.5 w-3.5" />
                        ) : (
                          <Clock className="h-3.5 w-3.5" />
                        )}
                        {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === "discussion" && (
                <div className="space-y-4">
                  {mockDiscussion.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        "rounded-xl border p-4",
                        message.isRequester ? "border-primary/30 bg-primary/5" : "border-border bg-card",
                      )}
                    >
                      <div className="mb-2 flex items-center gap-2">
                        <div
                          className={cn(
                            "flex h-8 w-8 items-center justify-center rounded-full",
                            message.isRequester ? "bg-primary/10" : "bg-secondary",
                          )}
                        >
                          <User
                            className={cn("h-4 w-4", message.isRequester ? "text-primary" : "text-muted-foreground")}
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-foreground">{message.author}</span>
                            {message.isRequester && (
                              <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">
                                Requester
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">{formatDate(message.timestamp)}</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{message.message}</p>
                    </div>
                  ))}

                  {/* Reply input */}
                  <div className="flex gap-3 rounded-xl border border-border bg-card p-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary">
                      <User className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Write a message..."
                        value={discussionMessage}
                        onChange={(e) => setDiscussionMessage(e.target.value)}
                        className="min-h-[80px] resize-none border-0 bg-transparent p-0 focus-visible:ring-0"
                      />
                      <div className="mt-2 flex justify-end">
                        <Button size="sm" className="rounded-lg" disabled={!discussionMessage.trim()}>
                          <Send className="mr-2 h-4 w-4" />
                          Send
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar: Submission form */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 rounded-xl border border-border bg-card p-5">
                <h3 className="mb-4 text-base font-semibold text-foreground">Submit Work</h3>

                {/* File upload */}
                <div className="mb-4">
                  <label className="mb-2 block text-xs font-medium text-muted-foreground">Upload File</label>
                  <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-secondary/30 p-6 transition-colors hover:border-primary/50 hover:bg-secondary/50">
                    <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      {uploadedFile ? uploadedFile.name : "Click to upload or drag & drop"}
                    </span>
                    <span className="text-xs text-muted-foreground">JSON, CSV, ZIP up to 50MB</span>
                    <input
                      type="file"
                      className="hidden"
                      accept=".json,.csv,.zip"
                      onChange={(e) => setUploadedFile(e.target.files?.[0] || null)}
                    />
                  </label>
                </div>

                {/* Text submission */}
                <div className="mb-4">
                  <label className="mb-2 block text-xs font-medium text-muted-foreground">Notes / Description</label>
                  <Textarea
                    placeholder="Describe your submission, any notes for the requester..."
                    value={submissionText}
                    onChange={(e) => setSubmissionText(e.target.value)}
                    className="min-h-[120px] resize-none rounded-lg"
                  />
                </div>

                {/* Submit button */}
                <Button
                  onClick={handleSubmit}
                  className="w-full rounded-lg"
                  disabled={!submissionText && !uploadedFile}
                >
                  <Send className="mr-2 h-4 w-4" />
                  Submit Work
                </Button>

                {/* Devnet tooltip */}
                <p className="mt-4 rounded-lg bg-primary/5 p-3 text-center text-xs text-muted-foreground">
                  <MessageSquare className="mb-1 inline-block h-3.5 w-3.5 text-primary" /> This demo uses a devnet
                  wallet; no real funds required.
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Submit Confirmation Modal */}
      <ConfirmationModal
        open={showSubmitConfirm}
        onOpenChange={setShowSubmitConfirm}
        title="Submit Your Work?"
        description="Once submitted, your work will be reviewed by the requester and verified by AI. Make sure everything is correct before submitting."
        confirmLabel="Confirm Submission"
        cancelLabel="Cancel"
        onConfirm={handleConfirmSubmit}
        variant="info"
      />

      {/* Staking Modal */}
      <StakingModal
        open={showStakingModal}
        onOpenChange={setShowStakingModal}
        requiredStake={mockTask.stakeRequired}
        currentStake={currentUserStake}
        onConfirmStake={handleStakeConfirm}
      />
    </div>
  )
}
