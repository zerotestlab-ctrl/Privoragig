import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMockWallet } from "@/context/auth-context";
import { ArrowLeft, Plus, Trash2, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function CreateTask() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    reward: "",
    stakeRequired: "",
    eta: "1 day",
    tags: [] as string[],
    type: "micro" as "micro" | "macro",
    aiRequired: true,
  });
  const [tagInput, setTagInput] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type: inputType } = e.target;
    if (inputType === "checkbox") {
      setFormData(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, tagInput.trim()] }));
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
  };

  const handleSubmit = () => {
    const isValid = formData.title && formData.description && formData.reward && formData.stakeRequired;
    if (isValid) {
      setSubmitted(true);
      setTimeout(() => {
        setLocation("/marketplace");
      }, 2000);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />
        <div className="flex">
          <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
          <main className="flex-1 flex items-center justify-center p-6">
            <div className="text-center animate-in fade-in zoom-in duration-500">
              <div className="h-16 w-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8 text-emerald-500" />
              </div>
              <h2 className="text-2xl font-bold text-card-foreground mb-2">Task Created!</h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                Your task "{formData.title}" has been published to the marketplace. Redirecting...
              </p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const isFormValid = formData.title && formData.description && formData.reward && formData.stakeRequired;

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <Button 
            variant="ghost" 
            className="mb-6 gap-2 pl-0 hover:pl-2 transition-all" 
            onClick={() => setLocation("/marketplace")}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Marketplace
          </Button>

          <div className="max-w-3xl">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-card-foreground mb-2">Create New Task</h1>
              <p className="text-muted-foreground">Post a task for the Privora community to complete and earn SOL rewards.</p>
            </div>

            <div className="space-y-6">
              {/* Basic Info Card */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Task Details</CardTitle>
                  <CardDescription>Basic information about your task</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">Task Title *</label>
                    <Input
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      placeholder="e.g., Data Labeling for Product Reviews"
                      className="bg-secondary/30"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">Description *</label>
                    <Textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      placeholder="Describe what you need done. Be as specific as possible..."
                      rows={6}
                      className="bg-secondary/30 resize-none"
                    />
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">Task Type *</label>
                      <select
                        name="type"
                        value={formData.type}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 rounded-md border border-input bg-secondary/30 text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                      >
                        <option value="micro">Micro Task (Quick)</option>
                        <option value="macro">Macro Task (Complex)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">Time Estimate *</label>
                      <select
                        name="eta"
                        value={formData.eta}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 rounded-md border border-input bg-secondary/30 text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                      >
                        <option value="30 mins">30 minutes</option>
                        <option value="1 hour">1 hour</option>
                        <option value="2 hours">2 hours</option>
                        <option value="4 hours">4 hours</option>
                        <option value="1 day">1 day</option>
                        <option value="2 days">2 days</option>
                        <option value="1 week">1 week</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        name="aiRequired"
                        checked={formData.aiRequired}
                        onChange={handleInputChange}
                        className="h-4 w-4 rounded border-input"
                      />
                      <span className="text-sm font-medium text-card-foreground">Require AI Verification</span>
                    </label>
                    <p className="text-xs text-muted-foreground mt-1 ml-7">
                      Enable AI to automatically verify submission quality
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Compensation Card */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Compensation & Staking</CardTitle>
                  <CardDescription>Set the reward and staking requirements</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">Reward Amount (SOL) *</label>
                      <Input
                        type="number"
                        name="reward"
                        value={formData.reward}
                        onChange={handleInputChange}
                        placeholder="0.00"
                        step="0.01"
                        min="0"
                        className="bg-secondary/30"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Amount paid upon completion</p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">Stake Required (SOL) *</label>
                      <Input
                        type="number"
                        name="stakeRequired"
                        value={formData.stakeRequired}
                        onChange={handleInputChange}
                        placeholder="0.00"
                        step="0.01"
                        min="0"
                        className="bg-secondary/30"
                      />
                      <p className="text-xs text-muted-foreground mt-1">Collateral workers must provide</p>
                    </div>
                  </div>

                  <Alert className="bg-primary/5 border-primary/10">
                    <AlertDescription className="text-sm text-muted-foreground">
                      Total cost: <span className="font-mono font-semibold text-card-foreground">{(parseFloat(formData.reward) || 0).toFixed(2)} SOL</span> in rewards
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>

              {/* Tags Card */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Tags</CardTitle>
                  <CardDescription>Help workers find your task with relevant tags</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                      placeholder="Add a tag..."
                      className="bg-secondary/30"
                    />
                    <Button variant="outline" size="sm" onClick={addTag}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {formData.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="gap-2">
                        {tag}
                        <button onClick={() => removeTag(tag)} className="hover:opacity-70">
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setLocation("/marketplace")}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={!isFormValid}
                  className="flex-1"
                >
                  Publish Task
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
