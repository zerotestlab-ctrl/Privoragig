"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Info, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"

type ModalVariant = "info" | "success" | "warning" | "danger"

interface ConfirmationModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description?: string
  confirmLabel?: string
  cancelLabel?: string
  onConfirm?: () => void
  onCancel?: () => void
  variant?: ModalVariant
  loading?: boolean
}

const variantConfig: Record<
  ModalVariant,
  { icon: typeof Info; iconClass: string; buttonVariant: "default" | "destructive" }
> = {
  info: { icon: Info, iconClass: "text-blue-400", buttonVariant: "default" },
  success: { icon: CheckCircle, iconClass: "text-primary", buttonVariant: "default" },
  warning: { icon: AlertTriangle, iconClass: "text-yellow-400", buttonVariant: "default" },
  danger: { icon: XCircle, iconClass: "text-destructive", buttonVariant: "destructive" },
}

export function ConfirmationModal({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  onConfirm,
  onCancel,
  variant = "info",
  loading = false,
}: ConfirmationModalProps) {
  const config = variantConfig[variant]
  const Icon = config.icon

  const handleCancel = () => {
    onCancel?.()
    onOpenChange(false)
  }

  const handleConfirm = () => {
    onConfirm?.()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="flex flex-col items-center gap-4 text-center">
          <div className={cn("flex h-12 w-12 items-center justify-center rounded-full bg-secondary")}>
            <Icon className={cn("h-6 w-6", config.iconClass)} />
          </div>
          <div className="space-y-2">
            <DialogTitle className="text-lg font-semibold text-foreground">{title}</DialogTitle>
            {description && (
              <DialogDescription className="text-sm text-muted-foreground">{description}</DialogDescription>
            )}
          </div>
        </DialogHeader>
        <DialogFooter className="mt-6 flex gap-3 sm:justify-center">
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={loading}
            className="flex-1 rounded-lg sm:flex-none bg-transparent"
          >
            {cancelLabel}
          </Button>
          <Button
            variant={config.buttonVariant}
            onClick={handleConfirm}
            disabled={loading}
            className="flex-1 rounded-lg sm:flex-none"
          >
            {loading ? "Loading..." : confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
