import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Wallet, User, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface WalletModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onConnect: (type: "phantom" | "mock" | "guest", address?: string) => void
}

// Mock devnet wallet address
const MOCK_PHANTOM_ADDRESS = "9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin"
const MOCK_WALLET_ADDRESS = "7nYabs9dUhvxYwdTnrWVBL9MYviKSfrEbdWCUbcnwkpF"

export function WalletModal({ open, onOpenChange, onConnect }: WalletModalProps) {
  const [connecting, setConnecting] = useState<string | null>(null)

  const handleConnect = async (type: "phantom" | "mock" | "guest") => {
    setConnecting(type)

    // Simulate connection delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (type === "phantom") {
      onConnect("phantom", MOCK_PHANTOM_ADDRESS)
    } else if (type === "mock") {
      onConnect("mock", MOCK_WALLET_ADDRESS)
    } else {
      onConnect("guest")
    }

    setConnecting(null)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="text-center">
          <DialogTitle className="text-xl font-semibold text-foreground">Connect Wallet</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Choose how you want to connect to Privora
          </DialogDescription>
        </DialogHeader>

        {/* Devnet tooltip */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center justify-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-sm text-primary">
                <Info className="h-4 w-4" />
                <span>Demo mode - no real funds required</span>
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs text-center">
              <p>This demo uses a devnet wallet; no real funds required.</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Wallet options */}
        <div className="mt-4 flex flex-col gap-3">
          {/* Phantom */}
          <Button
            variant="outline"
            className="flex h-14 items-center justify-between rounded-xl border-border bg-secondary/50 px-4 hover:bg-secondary hover:border-primary/50"
            onClick={() => handleConnect("phantom")}
            disabled={connecting !== null}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#ab9ff2]">
                <svg viewBox="0 0 128 128" className="h-5 w-5" fill="white">
                  <path d="M64 0C28.7 0 0 28.7 0 64s28.7 64 64 64c11.2 0 21.7-2.9 30.8-7.9L48 64l46.8-56.1C85.7 2.9 75.2 0 64 0z" />
                </svg>
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Phantom</div>
                <div className="text-xs text-muted-foreground">Solana Wallet</div>
              </div>
            </div>
            {connecting === "phantom" ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            ) : (
              <span className="text-xs text-muted-foreground">Recommended</span>
            )}
          </Button>

          {/* Mock Wallet */}
          <Button
            variant="outline"
            className="flex h-14 items-center justify-between rounded-xl border-border bg-secondary/50 px-4 hover:bg-secondary hover:border-primary/50"
            onClick={() => handleConnect("mock")}
            disabled={connecting !== null}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
                <Wallet className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Mock Wallet</div>
                <div className="text-xs text-muted-foreground">Test without extension</div>
              </div>
            </div>
            {connecting === "mock" && (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            )}
          </Button>

          {/* Divider */}
          <div className="relative my-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-background px-3 text-xs text-muted-foreground">or</span>
            </div>
          </div>

          {/* Guest */}
          <Button
            variant="ghost"
            className="flex h-12 items-center justify-center gap-2 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground"
            onClick={() => handleConnect("guest")}
            disabled={connecting !== null}
          >
            {connecting === "guest" ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-muted-foreground border-t-transparent" />
            ) : (
              <>
                <User className="h-4 w-4" />
                <span>Continue as Guest</span>
              </>
            )}
          </Button>
        </div>

        {/* Footer note */}
        <p className="mt-4 text-center text-xs text-muted-foreground">
          By connecting, you agree to Privora&apos;s Terms of Service
        </p>
      </DialogContent>
    </Dialog>
  )
}
