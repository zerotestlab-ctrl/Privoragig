import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const fakeEvents = [
  "User #23 staked 100 SOL",
  "Task #55 completed",
  "User #9 joined as Worker",
  "Payment of 45 SOL released",
  "Reputation updated for User #11",
  "Task #102 submitted for review",
  "Dispute resolved for Task #98",
  "User #5 earned Gold tier status",
  "New task posted: Data Classification",
  "Weekly rewards distributed",
];

export default function FakeTransactionsFeed() {
  const [events, setEvents] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const event = fakeEvents[Math.floor(Math.random() * fakeEvents.length)];
      setEvents((prev) => [event, ...prev.slice(0, 8)]);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-secondary/50 border border-primary/20 rounded-xl p-4 font-mono text-xs h-64 overflow-hidden relative"
    >
      <div className="absolute top-3 left-4 text-primary text-[10px] uppercase tracking-wider font-semibold">
        Live Activity Stream
      </div>
      
      <div className="pt-8 space-y-1.5 text-muted-foreground">
        {events.length === 0 ? (
          <div className="text-muted-foreground/50 italic">Waiting for transactions...</div>
        ) : (
          events.map((event, i) => (
            <motion.div
              key={`${event}-${i}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className={`${i === 0 ? "text-primary font-semibold" : ""}`}
            >
              <span className="text-primary/50">[{new Date().toLocaleTimeString()}]</span> {event}
            </motion.div>
          ))
        )}
      </div>

      {/* Subtle glow effect */}
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />
    </motion.div>
  );
}
