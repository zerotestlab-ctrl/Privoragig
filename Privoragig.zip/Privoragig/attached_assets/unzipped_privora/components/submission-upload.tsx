"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Upload, FileUp, X, File, ImageIcon, FileText, Paperclip } from "lucide-react"
import { cn } from "@/lib/utils"

interface UploadedFile {
  file: File
  preview?: string
  type: "image" | "document" | "other"
}

interface SubmissionUploadProps {
  onSubmit: (data: { files: UploadedFile[]; notes: string }) => void
  isSubmitting?: boolean
}

export function SubmissionUpload({ onSubmit, isSubmitting = false }: SubmissionUploadProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [notes, setNotes] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const attachmentInputRef = useRef<HTMLInputElement>(null)

  const getFileType = (file: File): "image" | "document" | "other" => {
    if (file.type.startsWith("image/")) return "image"
    if (file.type.includes("pdf") || file.type.includes("document") || file.type.includes("text")) return "document"
    return "other"
  }

  const handleFileSelect = (selectedFiles: FileList | null, isAttachment = false) => {
    if (!selectedFiles) return

    const newFiles: UploadedFile[] = Array.from(selectedFiles).map((file) => {
      const type = getFileType(file)
      const uploadedFile: UploadedFile = { file, type }

      if (type === "image") {
        uploadedFile.preview = URL.createObjectURL(file)
      }

      return uploadedFile
    })

    setFiles((prev) => [...prev, ...newFiles])
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    handleFileSelect(e.dataTransfer.files)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const removeFile = (index: number) => {
    setFiles((prev) => {
      const newFiles = [...prev]
      if (newFiles[index].preview) {
        URL.revokeObjectURL(newFiles[index].preview!)
      }
      newFiles.splice(index, 1)
      return newFiles
    })
  }

  const handleSubmit = () => {
    if (files.length === 0 && !notes.trim()) return
    onSubmit({ files, notes })
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const FileIcon = ({ type }: { type: UploadedFile["type"] }) => {
    if (type === "image") return <ImageIcon className="h-5 w-5 text-primary" />
    if (type === "document") return <FileText className="h-5 w-5 text-chart-3" />
    return <File className="h-5 w-5 text-muted-foreground" />
  }

  return (
    <div className="space-y-6">
      {/* Main Upload Area */}
      <div>
        <label className="mb-2 block text-sm font-medium text-foreground">Submission Files</label>
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={cn(
            "relative cursor-pointer rounded-xl border-2 border-dashed p-8 text-center transition-all",
            isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-secondary/30",
          )}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files)}
          />
          <div className="flex flex-col items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Upload className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Drop files here or click to upload</p>
              <p className="mt-1 text-xs text-muted-foreground">JSON, CSV, images, or any deliverable files</p>
            </div>
          </div>
        </div>
      </div>

      {/* File Preview Grid */}
      {files.length > 0 && (
        <div className="space-y-3">
          <label className="block text-sm font-medium text-foreground">Uploaded Files ({files.length})</label>
          <div className="grid gap-3 sm:grid-cols-2">
            {files.map((uploadedFile, index) => (
              <div
                key={index}
                className="group relative flex items-center gap-3 rounded-lg border border-border bg-card p-3"
              >
                {/* Preview thumbnail or icon */}
                {uploadedFile.preview ? (
                  <div className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-secondary">
                    <img
                      src={uploadedFile.preview || "/placeholder.svg"}
                      alt={uploadedFile.file.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-secondary">
                    <FileIcon type={uploadedFile.type} />
                  </div>
                )}

                {/* File info */}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-foreground">{uploadedFile.file.name}</p>
                  <p className="text-xs text-muted-foreground">{formatFileSize(uploadedFile.file.size)}</p>
                </div>

                {/* Remove button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeFile(index)
                  }}
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Optional Attachment */}
      <div>
        <label className="mb-2 block text-sm font-medium text-foreground">
          Additional Attachments
          <span className="ml-1 text-xs text-muted-foreground">(optional)</span>
        </label>
        <button
          onClick={() => attachmentInputRef.current?.click()}
          className="flex w-full items-center gap-3 rounded-lg border border-dashed border-border bg-card/50 p-4 text-left transition-colors hover:border-primary/50 hover:bg-secondary/30"
        >
          <Paperclip className="h-5 w-5 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Add supporting documents, screenshots, or notes</span>
        </button>
        <input
          ref={attachmentInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => handleFileSelect(e.target.files, true)}
        />
      </div>

      {/* Notes */}
      <div>
        <label className="mb-2 block text-sm font-medium text-foreground">Submission Notes</label>
        <Textarea
          placeholder="Add any notes or comments about your submission..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="min-h-[120px] resize-none rounded-lg bg-card"
        />
      </div>

      {/* Submit Button */}
      <Button
        onClick={handleSubmit}
        disabled={isSubmitting || (files.length === 0 && !notes.trim())}
        className="w-full rounded-lg"
        size="lg"
      >
        {isSubmitting ? (
          <>
            <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
            Submitting...
          </>
        ) : (
          <>
            <FileUp className="mr-2 h-4 w-4" />
            Submit for Verification
          </>
        )}
      </Button>
    </div>
  )
}
