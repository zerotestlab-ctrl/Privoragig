"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { SubmissionUpload } from "@/components/submission-upload"
import { AIVerificationPanel } from "@/components/ai-verification-panel"
import { ArrowLeft, Bot, Coins, CheckCircle, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

// Mock task data
const mockTask = {
  id: "1",
  title: "Label 500 Product Images",
  reward: 25,
  stakeRequired: 50,
  requesterName: "DataCorp",
  requesterRating: 4.8,
  aiRequired: true,
}

type SubmissionStep = "upload" | "verifying" | "result"

export default function SubmitPage() {
  const params = useParams()
  const router = useRouter()
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [step, setStep] = useState<SubmissionStep>("upload")
  const [verificationProgress, setVerificationProgress] = useState(0)

  // Mock AI verification result
  const [verificationResult, setVerificationResult] = useState({
    score: 87,
    verdict: "pass" as const,
    comments: [
      "All 500 images successfully labeled with primary categories",
      "Secondary tags applied correctly to 94% of images",
      "3 images flagged for unclear content - appropriately documented",
      "JSON format follows required specification",
      "Minor inconsistency in category naming (2 instances)",
    ],
    recommendedPayout: 95,
    verifiedAt: "2 minutes ago",
    processingTime: "1m 23s",
  })

  const handleSubmit = async (data: { files: any[]; notes: string }) => {
    // Start verification process
    setStep("verifying")

    // Simulate AI verification progress
    const interval = setInterval(() => {
      setVerificationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setStep("result")
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 300)
  }

  const handleAcceptAndRelease = () => {
    // Handle payout release
    router.push("/dashboard")
  }

  const handleRequestHumanReview = () => {
    // Handle human review request
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={3} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="My Tasks"
        />

        <main className="flex-1 p-6">
          {/* Back button */}
          <button
            onClick={() => router.back()}
            className="mb-4 flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Task
          </button>

          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground">Submit Work</h1>
            <p className="mt-1 text-sm text-muted-foreground">Task: {mockTask.title}</p>
          </div>

          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center gap-2">
              {["Upload", "Verification", "Result"].map((label, index) => {
                const stepIndex = ["upload", "verifying", "result"].indexOf(step)
                const isActive = index === stepIndex
                const isComplete = index < stepIndex

                return (
                  <div key={label} className="flex items-center gap-2">
                    <div
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium transition-colors",
                        isComplete
                          ? "bg-primary text-primary-foreground"
                          : isActive
                            ? "bg-primary/20 text-primary ring-2 ring-primary"
                            : "bg-secondary text-muted-foreground",
                      )}
                    >
                      {isComplete ? <CheckCircle className="h-4 w-4" /> : index + 1}
                    </div>
                    <span className={cn("text-sm font-medium", isActive ? "text-foreground" : "text-muted-foreground")}>
                      {label}
                    </span>
                    {index < 2 && (
                      <div
                        className={cn("mx-2 h-px w-12 transition-colors", isComplete ? "bg-primary" : "bg-border")}
                      />
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {step === "upload" && (
                <div className="rounded-xl border border-border bg-card p-6">
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold text-foreground">Upload Your Submission</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Upload your completed work files and add any notes for the requester.
                    </p>
                  </div>
                  <SubmissionUpload onSubmit={handleSubmit} />
                </div>
              )}

              {step === "verifying" && (
                <div className="rounded-xl border border-border bg-card p-8">
                  <div className="flex flex-col items-center text-center">
                    <div className="relative mb-6">
                      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
                        <Bot className="h-10 w-10 text-primary animate-pulse" />
                      </div>
                      {/* Spinning ring */}
                      <div className="absolute inset-0 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
                    </div>

                    <h2 className="mb-2 text-xl font-semibold text-foreground">AI Verification in Progress</h2>
                    <p className="mb-6 text-sm text-muted-foreground">
                      Our AI is analyzing your submission for quality and accuracy...
                    </p>

                    {/* Progress bar */}
                    <div className="w-full max-w-md">
                      <div className="mb-2 flex justify-between text-sm">
                        <span className="text-muted-foreground">Analyzing...</span>
                        <span className="font-mono text-foreground">
                          {Math.min(100, Math.round(verificationProgress))}%
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-secondary overflow-hidden">
                        <div
                          className="h-full rounded-full bg-primary transition-all duration-300"
                          style={{ width: `${Math.min(100, verificationProgress)}%` }}
                        />
                      </div>
                    </div>

                    {/* Verification steps */}
                    <div className="mt-8 space-y-3 text-left w-full max-w-md">
                      {[
                        { label: "Parsing submission files", done: verificationProgress > 20 },
                        { label: "Checking format compliance", done: verificationProgress > 40 },
                        { label: "Validating content quality", done: verificationProgress > 60 },
                        { label: "Cross-referencing requirements", done: verificationProgress > 80 },
                        { label: "Generating report", done: verificationProgress >= 100 },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center gap-3">
                          {item.done ? (
                            <CheckCircle className="h-4 w-4 text-primary" />
                          ) : (
                            <div className="h-4 w-4 rounded-full border-2 border-border" />
                          )}
                          <span className={cn("text-sm", item.done ? "text-foreground" : "text-muted-foreground")}>
                            {item.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {step === "result" && (
                <AIVerificationPanel
                  result={verificationResult}
                  rewardAmount={mockTask.reward}
                  onAcceptAndRelease={handleAcceptAndRelease}
                  onRequestHumanReview={handleRequestHumanReview}
                />
              )}
            </div>

            {/* Sidebar Info */}
            <div className="space-y-4">
              {/* Task Summary */}
              <div className="rounded-xl border border-border bg-card p-4">
                <h3 className="mb-3 text-sm font-medium text-foreground">Task Summary</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Reward</span>
                    <div className="flex items-center gap-1.5 text-primary">
                      <Coins className="h-4 w-4" />
                      <span className="font-mono font-medium">{mockTask.reward} USDC</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Your Stake</span>
                    <span className="font-mono text-sm text-chart-3">{mockTask.stakeRequired} SOL</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Requester</span>
                    <span className="text-sm text-foreground">{mockTask.requesterName}</span>
                  </div>
                  {mockTask.aiRequired && (
                    <div className="flex items-center gap-2 rounded-lg bg-primary/10 p-2">
                      <Bot className="h-4 w-4 text-primary" />
                      <span className="text-xs text-primary">AI Verification Enabled</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Tips */}
              <div className="rounded-xl border border-border bg-card p-4">
                <h3 className="mb-3 text-sm font-medium text-foreground">Submission Tips</h3>
                <ul className="space-y-2 text-xs text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    Double-check file formats match requirements
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    Include all deliverables in a single submission
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    Add notes to explain any deviations
                  </li>
                  <li className="flex items-start gap-2">
                    <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-chart-3" />
                    Late submissions may affect your reputation
                  </li>
                </ul>
              </div>

              {/* Stakes warning */}
              <div className="rounded-xl border border-chart-3/30 bg-chart-3/5 p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-chart-3" />
                  <div>
                    <h4 className="text-sm font-medium text-chart-3">Stake at Risk</h4>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Your {mockTask.stakeRequired} SOL stake may be partially slashed if the submission fails quality
                      checks. Higher quality = full stake returned + reward.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
