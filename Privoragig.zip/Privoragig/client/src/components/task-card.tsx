import { Bot, Clock, Coins, Star, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Link } from "wouter"

export interface Task {
  id: string
  title: string
  description: string
  type: "micro" | "macro"
  reward: number
  stakeRequired: number
  eta: string
  tags: string[]
  aiRequired: boolean
  requesterRating: number
  requesterName: string
}

interface TaskCardProps {
  task: Task
  onTake?: (task: Task) => void
  className?: string
}

export function TaskCard({ task, onTake, className }: TaskCardProps) {
  return (
    <div
      className={cn(
        "group rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5",
        className,
      )}
    >
      {/* Header: Type badge + AI toggle */}
      <div className="mb-3 flex items-center justify-between">
        <span
          className={cn(
            "rounded-md px-2.5 py-1 text-xs font-medium",
            task.type === "micro" ? "bg-primary/10 text-primary" : "bg-chart-3/10 text-chart-3",
          )}
        >
          {task.type === "micro" ? "Micro" : "Macro"}
        </span>
        {task.aiRequired && (
          <div className="flex items-center gap-1.5 rounded-md bg-secondary px-2 py-1">
            <Bot className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs text-muted-foreground">AI Required</span>
          </div>
        )}
      </div>

      {/* Title */}
      <h3 className="mb-2 text-base font-semibold text-card-foreground line-clamp-1">{task.title}</h3>

      {/* Description */}
      <p className="mb-4 text-sm text-muted-foreground line-clamp-2">{task.description}</p>

      {/* Tags */}
      <div className="mb-4 flex flex-wrap gap-1.5">
        {task.tags.slice(0, 3).map((tag) => (
          <span key={tag} className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-secondary-foreground">
            {tag}
          </span>
        ))}
        {task.tags.length > 3 && (
          <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-muted-foreground">
            +{task.tags.length - 3}
          </span>
        )}
      </div>

      {/* Stats row */}
      <div className="mb-4 grid grid-cols-3 gap-2">
        <div className="rounded-lg bg-secondary/50 px-2.5 py-2 text-center">
          <div className="flex items-center justify-center gap-1 text-primary">
            <Coins className="h-3.5 w-3.5" />
            <span className="font-mono text-sm font-semibold">{task.reward}</span>
          </div>
          <span className="text-[10px] text-muted-foreground">SOL Reward</span>
        </div>
        <div className="rounded-lg bg-secondary/50 px-2.5 py-2 text-center">
          <div className="flex items-center justify-center gap-1 text-chart-3">
            <Coins className="h-3.5 w-3.5" />
            <span className="font-mono text-sm font-semibold">{task.stakeRequired}</span>
          </div>
          <span className="text-[10px] text-muted-foreground">Stake Req.</span>
        </div>
        <div className="rounded-lg bg-secondary/50 px-2.5 py-2 text-center">
          <div className="flex items-center justify-center gap-1 text-muted-foreground">
            <Clock className="h-3.5 w-3.5" />
            <span className="text-sm font-medium">{task.eta}</span>
          </div>
          <span className="text-[10px] text-muted-foreground">ETA</span>
        </div>
      </div>

      {/* Requester info */}
      <div className="mb-4 flex items-center justify-between rounded-lg bg-secondary/30 px-3 py-2">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary">
            <User className="h-3.5 w-3.5 text-muted-foreground" />
          </div>
          <span className="text-xs text-muted-foreground">{task.requesterName}</span>
        </div>
        <div className="flex items-center gap-1">
          <Star className="h-3.5 w-3.5 fill-chart-3 text-chart-3" />
          <span className="text-xs font-medium text-card-foreground">{task.requesterRating.toFixed(1)}</span>
        </div>
      </div>

      {/* Take button */}
      <Link href={`/task/${task.id}`}>
        <Button className="w-full rounded-lg" variant="default" onClick={() => onTake?.(task)}>
          Take Task
        </Button>
      </Link>
    </div>
  )
}
