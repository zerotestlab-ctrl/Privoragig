"use client"

import { useState } from "react"
import { FileText, Settings, Wallet, ChevronRight, ChevronLeft, Check, Sparkles, AlertTriangle, X } from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tooltip } from "@/components/tooltip"
import { cn } from "@/lib/utils"

const SKILL_TAGS = [
  "Data Labeling",
  "Image Classification",
  "Text Analysis",
  "Sentiment Analysis",
  "Translation",
  "Transcription",
  "Content Moderation",
  "Survey",
  "Research",
]

const STAKE_LEVELS = [
  { level: 1, amount: 10, label: "Basic" },
  { level: 2, amount: 25, label: "Standard" },
  { level: 3, amount: 50, label: "Advanced" },
  { level: 4, amount: 100, label: "Expert" },
  { level: 5, amount: 250, label: "Elite" },
]

const SUBMISSION_FORMATS = [
  { value: "text", label: "Text / Written Response" },
  { value: "file", label: "File Upload" },
  { value: "url", label: "URL / Link" },
  { value: "multiple", label: "Multiple Files" },
]

interface TaskFormData {
  // Step 1: Basics
  title: string
  description: string
  tags: string[]
  // Step 2: Settings
  rewardAmount: number
  stakeLevel: number
  aiVerification: boolean
  submissionFormat: string
  // Step 3: computed
  platformFee: number
  totalCost: number
}

export default function CreateTaskPage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [isPublishing, setIsPublishing] = useState(false)

  const [formData, setFormData] = useState<TaskFormData>({
    title: "",
    description: "",
    tags: [],
    rewardAmount: 50,
    stakeLevel: 2,
    aiVerification: true,
    submissionFormat: "text",
    platformFee: 0,
    totalCost: 0,
  })

  // Calculate fees
  const platformFeeRate = 0.025 // 2.5%
  const platformFee = formData.rewardAmount * platformFeeRate
  const totalCost = formData.rewardAmount + platformFee

  const steps = [
    { number: 1, title: "Basics", icon: FileText },
    { number: 2, title: "Settings", icon: Settings },
    { number: 3, title: "Escrow & Publish", icon: Wallet },
  ]

  const toggleTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.includes(tag) ? prev.tags.filter((t) => t !== tag) : [...prev.tags, tag],
    }))
  }

  const canProceed = () => {
    if (currentStep === 1) {
      return formData.title.trim().length > 0 && formData.description.trim().length > 0 && formData.tags.length > 0
    }
    if (currentStep === 2) {
      return formData.rewardAmount > 0 && formData.stakeLevel > 0
    }
    return true
  }

  const handlePublish = () => {
    setIsPublishing(true)
    // Simulate publishing
    setTimeout(() => {
      setIsPublishing(false)
      setShowConfirmModal(false)
      // Would redirect to task page
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={3} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="Create Task"
        />

        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground">Create New Task</h1>
            <p className="text-sm text-muted-foreground">Post a task to the Privora marketplace</p>
          </div>

          {/* Step Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-center">
              {steps.map((step, index) => {
                const Icon = step.icon
                const isActive = currentStep === step.number
                const isCompleted = currentStep > step.number

                return (
                  <div key={step.number} className="flex items-center">
                    <div className="flex flex-col items-center">
                      <div
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-full border-2 transition-colors",
                          isCompleted
                            ? "border-primary bg-primary text-primary-foreground"
                            : isActive
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border bg-card text-muted-foreground",
                        )}
                      >
                        {isCompleted ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                      </div>
                      <span
                        className={cn(
                          "mt-2 text-xs font-medium",
                          isActive ? "text-primary" : isCompleted ? "text-foreground" : "text-muted-foreground",
                        )}
                      >
                        {step.title}
                      </span>
                    </div>
                    {index < steps.length - 1 && (
                      <div
                        className={cn(
                          "mx-4 h-0.5 w-16 sm:w-24 md:w-32",
                          currentStep > step.number ? "bg-primary" : "bg-border",
                        )}
                      />
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          {/* Form Container */}
          <div className="mx-auto max-w-2xl">
            <div className="rounded-xl border border-border bg-card p-6">
              {/* Step 1: Basics */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Task Title
                      <Tooltip content="Choose a clear, descriptive title that helps workers understand the task at a glance." />
                    </label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                      placeholder="e.g., Label 1000 product images"
                      className="bg-input"
                    />
                  </div>

                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Description
                      <Tooltip content="Provide detailed instructions, requirements, and expected deliverables. The more specific, the better results you'll receive." />
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                      placeholder="Describe what needs to be done, any specific requirements, and the expected output format..."
                      rows={5}
                      className="w-full rounded-lg border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                    />
                  </div>

                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Skill Tags
                      <Tooltip content="Select relevant skills to help qualified workers find your task. Choose at least one tag." />
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {SKILL_TAGS.map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => toggleTag(tag)}
                          className={cn(
                            "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                            formData.tags.includes(tag)
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-secondary-foreground hover:bg-accent",
                          )}
                        >
                          {formData.tags.includes(tag) && <Check className="mr-1 inline h-3 w-3" />}
                          {tag}
                        </button>
                      ))}
                    </div>
                    {formData.tags.length === 0 && (
                      <p className="mt-2 text-xs text-muted-foreground">Select at least one tag</p>
                    )}
                  </div>
                </div>
              )}

              {/* Step 2: Settings */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Reward Amount (USDC)
                      <Tooltip content="Set the total reward for completing this task. Higher rewards attract more qualified workers." />
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">$</span>
                      <Input
                        type="number"
                        value={formData.rewardAmount}
                        onChange={(e) => setFormData((prev) => ({ ...prev, rewardAmount: Number(e.target.value) }))}
                        className="bg-input pl-7"
                        min={1}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Stake Required Level
                      <Tooltip
                        content={
                          <div className="space-y-2">
                            <p className="font-medium">Stake levels determine worker commitment:</p>
                            <p>
                              Workers must stake tokens to accept your task. Higher levels mean more qualified workers
                              with more skin in the game.
                            </p>
                            <p className="text-amber-400">
                              <AlertTriangle className="mr-1 inline h-3 w-3" />
                              If a worker fails to deliver, their stake is slashed and you receive compensation.
                            </p>
                          </div>
                        }
                      />
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {STAKE_LEVELS.map((level) => (
                        <button
                          key={level.level}
                          type="button"
                          onClick={() => setFormData((prev) => ({ ...prev, stakeLevel: level.level }))}
                          className={cn(
                            "flex flex-col items-center rounded-lg border p-3 transition-colors",
                            formData.stakeLevel === level.level
                              ? "border-primary bg-primary/10"
                              : "border-border bg-secondary hover:bg-accent",
                          )}
                        >
                          <span
                            className={cn(
                              "text-lg font-bold",
                              formData.stakeLevel === level.level ? "text-primary" : "text-foreground",
                            )}
                          >
                            Lvl {level.level}
                          </span>
                          <span className="text-xs text-muted-foreground">{level.amount} SOL</span>
                          <span className="mt-1 text-[10px] text-muted-foreground">{level.label}</span>
                        </button>
                      ))}
                    </div>
                    <p className="mt-2 flex items-center gap-1 text-xs text-amber-500">
                      <AlertTriangle className="h-3 w-3" />
                      Worker stake is slashed if they fail to deliver quality work
                    </p>
                  </div>

                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      AI Verification
                      <Tooltip content="Enable AI-powered quality verification to automatically check submissions before payout. Recommended for most tasks." />
                    </label>
                    <button
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, aiVerification: !prev.aiVerification }))}
                      className={cn(
                        "flex w-full items-center justify-between rounded-lg border p-4 transition-colors",
                        formData.aiVerification ? "border-primary bg-primary/10" : "border-border bg-secondary",
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-lg",
                            formData.aiVerification ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground",
                          )}
                        >
                          <Sparkles className="h-5 w-5" />
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-medium text-foreground">AI Verification</p>
                          <p className="text-xs text-muted-foreground">Automatically verify submission quality</p>
                        </div>
                      </div>
                      <div
                        className={cn(
                          "h-6 w-11 rounded-full p-0.5 transition-colors",
                          formData.aiVerification ? "bg-primary" : "bg-muted",
                        )}
                      >
                        <div
                          className={cn(
                            "h-5 w-5 rounded-full bg-white transition-transform",
                            formData.aiVerification ? "translate-x-5" : "translate-x-0",
                          )}
                        />
                      </div>
                    </button>
                  </div>

                  <div>
                    <label className="mb-2 flex items-center gap-2 text-sm font-medium text-card-foreground">
                      Submission Format
                      <Tooltip content="Choose how workers should submit their completed work." />
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {SUBMISSION_FORMATS.map((format) => (
                        <button
                          key={format.value}
                          type="button"
                          onClick={() => setFormData((prev) => ({ ...prev, submissionFormat: format.value }))}
                          className={cn(
                            "rounded-lg border px-4 py-3 text-left text-sm font-medium transition-colors",
                            formData.submissionFormat === format.value
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border bg-secondary text-foreground hover:bg-accent",
                          )}
                        >
                          {format.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Escrow & Publish */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="rounded-lg border border-border bg-secondary/50 p-4">
                    <h3 className="mb-4 text-sm font-semibold text-foreground">Task Summary</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Title</span>
                        <span className="text-sm font-medium text-foreground">{formData.title || "—"}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Tags</span>
                        <div className="flex flex-wrap justify-end gap-1">
                          {formData.tags.map((tag) => (
                            <span key={tag} className="rounded bg-primary/10 px-2 py-0.5 text-xs text-primary">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Stake Level</span>
                        <span className="text-sm font-medium text-foreground">
                          Level {formData.stakeLevel} ({STAKE_LEVELS[formData.stakeLevel - 1]?.amount} SOL)
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">AI Verification</span>
                        <span
                          className={cn(
                            "text-sm font-medium",
                            formData.aiVerification ? "text-primary" : "text-muted-foreground",
                          )}
                        >
                          {formData.aiVerification ? "Enabled" : "Disabled"}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Submission Format</span>
                        <span className="text-sm font-medium text-foreground">
                          {SUBMISSION_FORMATS.find((f) => f.value === formData.submissionFormat)?.label}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
                    <div className="mb-2 flex items-center gap-2">
                      <Wallet className="h-4 w-4 text-primary" />
                      <h3 className="text-sm font-semibold text-foreground">Escrow Payment</h3>
                      <Tooltip
                        content={
                          <div className="space-y-2">
                            <p>
                              Your payment is held in a secure escrow smart contract until the task is completed and
                              verified.
                            </p>
                            <p>If no worker accepts within 7 days, you can reclaim your funds.</p>
                          </div>
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Task Reward</span>
                        <span className="font-mono text-sm text-foreground">${formData.rewardAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1 text-sm text-muted-foreground">
                          Platform Fee (2.5%)
                          <Tooltip content="A small fee to maintain the Privora platform and AI verification services." />
                        </span>
                        <span className="font-mono text-sm text-muted-foreground">${platformFee.toFixed(2)}</span>
                      </div>
                      <div className="my-2 border-t border-border" />
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-foreground">Total Cost</span>
                        <span className="font-mono text-lg font-bold text-primary">${totalCost.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
                    <div className="flex gap-3">
                      <AlertTriangle className="h-5 w-5 shrink-0 text-amber-500" />
                      <div className="text-sm">
                        <p className="font-medium text-amber-500">Important</p>
                        <p className="mt-1 text-muted-foreground">
                          Once published, your funds will be locked in escrow. You can cancel and reclaim your funds
                          only if no worker has accepted the task yet.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="mt-8 flex items-center justify-between border-t border-border pt-6">
                {currentStep > 1 ? (
                  <Button variant="outline" onClick={() => setCurrentStep((s) => s - 1)} className="gap-2">
                    <ChevronLeft className="h-4 w-4" />
                    Back
                  </Button>
                ) : (
                  <div />
                )}

                {currentStep < 3 ? (
                  <Button onClick={() => setCurrentStep((s) => s + 1)} disabled={!canProceed()} className="gap-2">
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button onClick={() => setShowConfirmModal(true)} className="gap-2">
                    <Wallet className="h-4 w-4" />
                    Publish & Escrow
                  </Button>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Confirm Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground">Confirm Publication</h3>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="mb-4 text-sm text-muted-foreground">
              You are about to publish this task and deposit{" "}
              <span className="font-semibold text-primary">${totalCost.toFixed(2)}</span> into escrow.
            </p>

            <div className="mb-6 rounded-lg bg-secondary/50 p-4">
              <p className="text-sm font-medium text-foreground">{formData.title}</p>
              <p className="mt-1 text-xs text-muted-foreground">{formData.tags.join(", ")}</p>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowConfirmModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handlePublish} disabled={isPublishing} className="flex-1 gap-2">
                {isPublishing ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4" />
                    Confirm & Publish
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
