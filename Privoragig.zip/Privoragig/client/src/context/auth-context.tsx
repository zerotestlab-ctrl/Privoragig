import React, { createContext, useContext, useState, useEffect } from "react";
import { useLocation } from "wouter";

interface User {
  wallet: string;
  staked: number;
  balance: number;
  type: "phantom" | "mock" | "guest";
}

interface AuthContextType {
  user: User | null;
  login: (type?: "phantom" | "mock" | "guest", address?: string) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const MOCK_USER: User = {
  wallet: "9xQeLly...FiN",
  staked: 12,
  balance: 4.2,
  type: "mock"
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [location, setLocation] = useLocation();

  const login = (type: "phantom" | "mock" | "guest" = "mock", address?: string) => {
    setIsLoading(true);
    // Simulate network delay
    setTimeout(() => {
      let newUser: User;
      
      if (type === "guest") {
        newUser = {
          wallet: "Guest",
          staked: 0,
          balance: 0,
          type: "guest"
        };
      } else {
        newUser = {
          ...MOCK_USER,
          type,
          wallet: address ? `${address.slice(0, 4)}...${address.slice(-4)}` : MOCK_USER.wallet
        };
      }
      
      setUser(newUser);
      setIsLoading(false);
      
      // If we're on the landing page, go to dashboard
      if (location === "/") {
        setLocation("/dashboard");
      }
    }, 800);
  };

  const logout = () => {
    setUser(null);
    setLocation("/");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useMockWallet() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useMockWallet must be used within an AuthProvider");
  }
  return context;
}
