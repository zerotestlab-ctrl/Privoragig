import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { useMockWallet } from "@/context/auth-context";
import { Star, TrendingUp, CheckCircle2, AlertCircle, Award, Zap, Eye } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";

export default function Reputation() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user) return null;

  const reputationScore = 82;
  const maxScore = 100;
  const scorePercentage = (reputationScore / maxScore) * 100;

  const metrics = [
    { label: "Tasks Completed", value: "12", subtext: "this month", icon: CheckCircle2, color: "text-emerald-500" },
    { label: "Disputes", value: "0", subtext: "active", icon: AlertCircle, color: "text-red-500" },
    { label: "Completion Rate", value: "98%", subtext: "success", icon: TrendingUp, color: "text-primary" },
    { label: "Avg. Quality Score", value: "9.2/10", subtext: "verified", icon: Star, color: "text-chart-3" },
  ];

  const badges = [
    { id: 1, name: "Verified Contributor", icon: CheckCircle2, description: "Completed 5+ verified tasks", earned: true },
    { id: 2, name: "Quality Master", icon: Star, description: "Maintained 9.0+ quality score", earned: true },
    { id: 3, name: "Speed Demon", icon: Zap, description: "Completed task 2x faster than average", earned: false },
    { id: 4, name: "Trusted Partner", icon: Award, description: "0 disputes across 50+ tasks", earned: false },
  ];

  const recentActivity = [
    { id: 1, action: "Task completed", task: "Data Labeling #1234", reward: "+25.00 SOL", date: "2 hours ago", status: "verified" },
    { id: 2, action: "Quality review", task: "Image Classification #1201", score: "9.5/10", date: "6 hours ago", status: "approved" },
    { id: 3, action: "Task completed", task: "Sentiment Analysis #1198", reward: "+18.75 SOL", date: "1 day ago", status: "verified" },
    { id: 4, action: "Stake increase", stake: "+50 SOL staked", boost: "+0.3x multiplier", date: "2 days ago", status: "active" },
  ];

  const scoreColor = reputationScore >= 80 ? "text-emerald-500" : reputationScore >= 60 ? "text-chart-3" : "text-red-500";

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <div className="max-w-5xl">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-card-foreground mb-2">Your Reputation</h1>
              <p className="text-muted-foreground">Track your performance, badges, and standing in the Privora community.</p>
            </div>

            <div className="grid gap-6 lg:grid-cols-3">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-6">
                {/* Score Card */}
                <Card className="border-border bg-gradient-to-br from-card to-primary/5">
                  <CardHeader>
                    <CardTitle>Reputation Score</CardTitle>
                    <CardDescription>Your overall standing in the community</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Your Score</p>
                        <p className={`text-5xl font-bold ${scoreColor}`}>{reputationScore}</p>
                        <p className="text-sm text-muted-foreground mt-1">out of {maxScore}</p>
                      </div>
                      <div className="text-center">
                        <div className="h-24 w-24 rounded-full border-4 border-primary/20 flex items-center justify-center bg-secondary/50">
                          <span className="text-2xl font-bold text-primary">{scorePercentage.toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>

                    <Progress value={scorePercentage} className="h-3" />

                    <Alert className="bg-emerald-500/5 border-emerald-500/20">
                      <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      <AlertTitle>Excellent Standing</AlertTitle>
                      <AlertDescription className="text-muted-foreground">
                        You're in the top 15% of contributors. Keep up the great work!
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>

                {/* Metrics Grid */}
                <div className="grid gap-4 sm:grid-cols-2">
                  {metrics.map((metric) => {
                    const Icon = metric.icon;
                    return (
                      <Card key={metric.label} className="border-border bg-card">
                        <CardContent className="pt-6">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="text-xs text-muted-foreground mb-1">{metric.label}</p>
                              <p className="text-2xl font-bold text-card-foreground">{metric.value}</p>
                              <p className="text-xs text-muted-foreground mt-1">{metric.subtext}</p>
                            </div>
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                              <Icon className={`h-5 w-5 ${metric.color}`} />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {/* Badges Section */}
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                    <CardDescription>Earn badges by completing tasks and maintaining quality</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {badges.map((badge) => {
                        const BadgeIcon = badge.icon;
                        return (
                          <div
                            key={badge.id}
                            className={`p-4 rounded-lg border transition-all ${
                              badge.earned
                                ? "border-primary/50 bg-primary/5"
                                : "border-border/50 bg-secondary/20 opacity-50"
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                                badge.earned ? "bg-primary/10" : "bg-secondary/50"
                              }`}>
                                <BadgeIcon className={`h-5 w-5 ${badge.earned ? "text-primary" : "text-muted-foreground"}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-semibold text-card-foreground">{badge.name}</p>
                                <p className="text-xs text-muted-foreground mt-0.5">{badge.description}</p>
                              </div>
                              {badge.earned && (
                                <Badge variant="secondary" className="shrink-0 mt-0.5">Earned</Badge>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Sidebar */}
              <div className="space-y-6">
                {/* Tier Info */}
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-base">Your Tier</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center py-2">
                      <Badge className="mb-3 bg-primary/10 text-primary hover:bg-primary/20">GOLD</Badge>
                      <p className="text-sm font-semibold text-card-foreground">Gold Member</p>
                      <p className="text-xs text-muted-foreground mt-1">Top tier contributor</p>
                    </div>

                    <div className="space-y-2 text-xs text-muted-foreground">
                      <div className="flex items-center justify-between p-2 rounded-lg bg-secondary/50">
                        <span>Premium task access</span>
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg bg-secondary/50">
                        <span>Bonus APY on stake</span>
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg bg-secondary/50">
                        <span>Priority support</span>
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Trend */}
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-base">Score Trend</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">30 Days Ago</span>
                        <span className="font-semibold">75</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">7 Days Ago</span>
                        <span className="font-semibold">79</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Today</span>
                        <span className="font-semibold text-primary">82</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 pt-2 text-xs text-emerald-500 font-medium">
                      <TrendingUp className="h-3.5 w-3.5" />
                      +7 points this month
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Recent Activity */}
            <Card className="border-border bg-card mt-6">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your recent tasks and reputation events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.map((activity) => (
                    <div
                      key={activity.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-secondary/30 hover:border-primary/30 transition-colors"
                    >
                      <div className="flex-1">
                        <p className="text-sm font-medium text-card-foreground">{activity.action}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {("task" in activity && activity.task) || ("stake" in activity && activity.stake)}
                        </p>
                      </div>
                      <div className="text-right mr-4">
                        <p className="text-sm font-semibold text-card-foreground">
                          {("reward" in activity && activity.reward) || ("score" in activity && activity.score) || ("boost" in activity && activity.boost)}
                        </p>
                        <p className="text-xs text-muted-foreground">{activity.date}</p>
                      </div>
                      <Badge variant="secondary" className="text-xs">{activity.status}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
