"use client"

import { useState } from "react"
import {
  Coins,
  TrendingUp,
  TrendingDown,
  Shield,
  Award,
  Crown,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  CheckCircle2,
  Clock,
  XCircle,
  Zap,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { ConfirmationModal } from "@/components/confirmation-modal"

// Stake tier definitions
const stakeTiers = [
  {
    name: "Bronze",
    icon: Shield,
    minStake: 0,
    maxStake: 49,
    color: "text-amber-600",
    bgColor: "bg-amber-600/10",
    borderColor: "border-amber-600/30",
    benefits: ["Access to micro tasks", "Basic reputation", "Standard payouts"],
  },
  {
    name: "Silver",
    icon: Award,
    minStake: 50,
    maxStake: 199,
    color: "text-slate-300",
    bgColor: "bg-slate-300/10",
    borderColor: "border-slate-300/30",
    benefits: ["Access to all tasks", "Priority queue", "5% bonus rewards", "Lower fees"],
  },
  {
    name: "Gold",
    icon: Crown,
    minStake: 200,
    maxStake: Number.POSITIVE_INFINITY,
    color: "text-yellow-400",
    bgColor: "bg-yellow-400/10",
    borderColor: "border-yellow-400/30",
    benefits: ["Exclusive high-value tasks", "10% bonus rewards", "Lowest fees", "Governance voting"],
  },
]

// Mock slashing history
const slashingHistory = [
  {
    id: 1,
    date: "2024-01-15",
    taskId: "#1234",
    taskTitle: "Data labeling batch",
    reason: "Quality below threshold (AI score: 42/100)",
    amountSlashed: 5.0,
    originalStake: 25.0,
    status: "completed",
  },
  {
    id: 2,
    date: "2024-01-10",
    taskId: "#1198",
    taskTitle: "Image classification",
    reason: "Deadline missed by 48+ hours",
    amountSlashed: 10.0,
    originalStake: 50.0,
    status: "completed",
  },
  {
    id: 3,
    date: "2023-12-28",
    taskId: "#1156",
    taskTitle: "Sentiment analysis",
    reason: "Submission rejected after human review",
    amountSlashed: 7.5,
    originalStake: 25.0,
    status: "appealed",
  },
  {
    id: 4,
    date: "2023-12-15",
    taskId: "#1089",
    taskTitle: "Text summarization",
    reason: "Plagiarism detected",
    amountSlashed: 25.0,
    originalStake: 50.0,
    status: "completed",
  },
]

// Mock current state
const mockUserStake = {
  currentStake: 125.0,
  availableBalance: 1234.56,
  pendingRewards: 12.35,
  lifetimeEarnings: 2450.0,
  tasksCompleted: 47,
  slashCount: 4,
  totalSlashed: 47.5,
}

export default function StakeDashboardPage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [stakeAmount, setStakeAmount] = useState("")
  const [unstakeAmount, setUnstakeAmount] = useState("")
  const [activeTab, setActiveTab] = useState<"stake" | "unstake">("stake")
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [confirmAction, setConfirmAction] = useState<"stake" | "unstake" | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  // Determine current tier
  const currentTier =
    stakeTiers.find(
      (tier) => mockUserStake.currentStake >= tier.minStake && mockUserStake.currentStake <= tier.maxStake,
    ) || stakeTiers[0]

  // Calculate progress to next tier
  const nextTier = stakeTiers.find((tier) => tier.minStake > mockUserStake.currentStake)
  const progressToNext = nextTier
    ? ((mockUserStake.currentStake - currentTier.minStake) / (nextTier.minStake - currentTier.minStake)) * 100
    : 100

  const handleStakeAction = () => {
    const amount = activeTab === "stake" ? stakeAmount : unstakeAmount
    if (!amount || Number.parseFloat(amount) <= 0) return
    setConfirmAction(activeTab)
    setShowConfirmModal(true)
  }

  const handleConfirm = () => {
    setIsProcessing(true)
    setTimeout(() => {
      setIsProcessing(false)
      setShowConfirmModal(false)
      setStakeAmount("")
      setUnstakeAmount("")
    }, 1500)
  }

  const TierIcon = currentTier.icon

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={2} />

      <div className="flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          activeItem="Stake"
        />

        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground">Stake Dashboard</h1>
            <p className="text-sm text-muted-foreground">Manage your stake, unlock tiers, and view slashing history.</p>
          </div>

          {/* Stats Row */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Current Stake</span>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                  <Coins className="h-4 w-4 text-primary" />
                </div>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-card-foreground">{mockUserStake.currentStake.toFixed(2)}</span>
                <span className="text-sm text-muted-foreground">SOL</span>
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                <TierIcon className={`h-4 w-4 ${currentTier.color}`} />
                <span className={`text-xs font-medium ${currentTier.color}`}>{currentTier.name} Tier</span>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Pending Rewards</span>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10">
                  <TrendingUp className="h-4 w-4 text-emerald-500" />
                </div>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-emerald-500">+{mockUserStake.pendingRewards.toFixed(2)}</span>
                <span className="text-sm text-muted-foreground">SOL</span>
              </div>
              <div className="mt-2 flex items-center gap-1">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Claimable in 2 days</span>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Lifetime Earnings</span>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                  <Zap className="h-4 w-4 text-primary" />
                </div>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-card-foreground">
                  {mockUserStake.lifetimeEarnings.toFixed(0)}
                </span>
                <span className="text-sm text-muted-foreground">SOL</span>
              </div>
              <div className="mt-2 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                <span className="text-xs text-muted-foreground">{mockUserStake.tasksCompleted} tasks completed</span>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total Slashed</span>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-destructive/10">
                  <TrendingDown className="h-4 w-4 text-destructive" />
                </div>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-bold text-destructive">-{mockUserStake.totalSlashed.toFixed(2)}</span>
                <span className="text-sm text-muted-foreground">SOL</span>
              </div>
              <div className="mt-2 flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-chart-3" />
                <span className="text-xs text-muted-foreground">{mockUserStake.slashCount} slash events</span>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Stake Tiers */}
            <div className="lg:col-span-2 space-y-6">
              <div className="rounded-xl border border-border bg-card p-5">
                <h2 className="mb-4 text-lg font-semibold text-card-foreground">Stake Tiers</h2>

                {/* Progress bar */}
                {nextTier && (
                  <div className="mb-5">
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Progress to {nextTier.name}</span>
                      <span className="font-mono text-primary">
                        {mockUserStake.currentStake.toFixed(0)} / {nextTier.minStake} SOL
                      </span>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full bg-primary transition-all duration-500"
                        style={{ width: `${Math.min(progressToNext, 100)}%` }}
                      />
                    </div>
                    <p className="mt-1.5 text-xs text-muted-foreground">
                      Stake {(nextTier.minStake - mockUserStake.currentStake).toFixed(0)} more SOL to reach{" "}
                      {nextTier.name}
                    </p>
                  </div>
                )}

                {/* Tier cards */}
                <div className="grid gap-4 sm:grid-cols-3">
                  {stakeTiers.map((tier) => {
                    const isActive = tier.name === currentTier.name
                    const isLocked = tier.minStake > mockUserStake.currentStake
                    const Icon = tier.icon

                    return (
                      <div
                        key={tier.name}
                        className={`relative rounded-xl border p-4 transition-all ${
                          isActive
                            ? `${tier.borderColor} ${tier.bgColor}`
                            : isLocked
                              ? "border-border bg-secondary/30 opacity-60"
                              : "border-border bg-card"
                        }`}
                      >
                        {isActive && (
                          <div className="absolute -top-2 -right-2 rounded-full bg-primary px-2 py-0.5 text-[10px] font-medium text-primary-foreground">
                            Current
                          </div>
                        )}

                        <div className="mb-3 flex items-center gap-2">
                          <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${tier.bgColor}`}>
                            <Icon className={`h-5 w-5 ${tier.color}`} />
                          </div>
                          <div>
                            <h3 className={`font-semibold ${isActive ? tier.color : "text-card-foreground"}`}>
                              {tier.name}
                            </h3>
                            <p className="text-xs text-muted-foreground">
                              {tier.maxStake === Number.POSITIVE_INFINITY
                                ? `${tier.minStake}+ SOL`
                                : `${tier.minStake}-${tier.maxStake} SOL`}
                            </p>
                          </div>
                        </div>

                        <ul className="space-y-1.5">
                          {tier.benefits.map((benefit, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-xs text-muted-foreground">
                              <CheckCircle2
                                className={`mt-0.5 h-3 w-3 shrink-0 ${isActive ? tier.color : "text-muted-foreground"}`}
                              />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Slashing History */}
              <div className="rounded-xl border border-border bg-card p-5">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-card-foreground">Slashing History</h2>
                  <div className="flex items-center gap-1.5 rounded-lg bg-destructive/10 px-2.5 py-1">
                    <AlertTriangle className="h-3.5 w-3.5 text-destructive" />
                    <span className="text-xs font-medium text-destructive">{slashingHistory.length} events</span>
                  </div>
                </div>

                {slashingHistory.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CheckCircle2 className="mb-2 h-10 w-10 text-emerald-500" />
                    <p className="text-sm font-medium text-card-foreground">No slashing events</p>
                    <p className="text-xs text-muted-foreground">Keep up the good work!</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {slashingHistory.map((event) => (
                      <div
                        key={event.id}
                        className="rounded-lg border border-border bg-secondary/30 p-4 transition-colors hover:bg-secondary/50"
                      >
                        <div className="mb-2 flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs text-muted-foreground">{event.taskId}</span>
                            <span className="text-sm font-medium text-card-foreground">{event.taskTitle}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            {event.status === "appealed" ? (
                              <span className="rounded-full bg-chart-3/10 px-2 py-0.5 text-[10px] font-medium text-chart-3">
                                Appealed
                              </span>
                            ) : (
                              <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                                Completed
                              </span>
                            )}
                          </div>
                        </div>
                        <p className="mb-2 text-xs text-muted-foreground">{event.reason}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">{event.date}</span>
                          <div className="flex items-center gap-3">
                            <span className="text-xs text-muted-foreground">Stake: {event.originalStake} SOL</span>
                            <span className="flex items-center gap-1 font-mono text-sm font-medium text-destructive">
                              <ArrowDownRight className="h-3.5 w-3.5" />-{event.amountSlashed} SOL
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Slashing info tooltip */}
                <div className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-secondary/30 p-3">
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <div className="text-xs text-muted-foreground">
                    <p className="mb-1 font-medium text-card-foreground">About Slashing</p>
                    <p>
                      Stakes may be partially slashed if submissions fail AI verification, miss deadlines, or are
                      rejected after human review. Higher quality work protects your stake and reputation.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Stake/Unstake Form */}
            <div className="space-y-6">
              <div className="rounded-xl border border-border bg-card p-5">
                <h2 className="mb-4 text-lg font-semibold text-card-foreground">Manage Stake</h2>

                {/* Tab switcher */}
                <div className="mb-4 flex rounded-lg bg-secondary p-1">
                  <button
                    onClick={() => setActiveTab("stake")}
                    className={`flex-1 rounded-md px-3 py-2 text-sm font-medium transition-all ${
                      activeTab === "stake"
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <ArrowUpRight className="mr-1.5 inline-block h-4 w-4" />
                    Stake
                  </button>
                  <button
                    onClick={() => setActiveTab("unstake")}
                    className={`flex-1 rounded-md px-3 py-2 text-sm font-medium transition-all ${
                      activeTab === "unstake"
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <ArrowDownRight className="mr-1.5 inline-block h-4 w-4" />
                    Unstake
                  </button>
                </div>

                {activeTab === "stake" ? (
                  <div className="space-y-4">
                    <div>
                      <label className="mb-1.5 block text-xs text-muted-foreground">Amount to Stake</label>
                      <div className="relative">
                        <input
                          type="number"
                          value={stakeAmount}
                          onChange={(e) => setStakeAmount(e.target.value)}
                          placeholder="0.00"
                          className="w-full rounded-lg border border-border bg-input px-3 py-2.5 pr-14 font-mono text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                          SOL
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs text-muted-foreground">
                        Available:{" "}
                        <span className="font-mono text-foreground">
                          {mockUserStake.availableBalance.toFixed(2)} SOL
                        </span>
                      </p>
                    </div>

                    {/* Quick amounts */}
                    <div className="flex gap-2">
                      {[25, 50, 100].map((amount) => (
                        <button
                          key={amount}
                          onClick={() => setStakeAmount(amount.toString())}
                          className="flex-1 rounded-lg border border-border bg-secondary/50 px-2 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                        >
                          {amount} SOL
                        </button>
                      ))}
                      <button
                        onClick={() => setStakeAmount(mockUserStake.availableBalance.toString())}
                        className="flex-1 rounded-lg border border-primary/50 bg-primary/10 px-2 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
                      >
                        Max
                      </button>
                    </div>

                    <Button
                      className="w-full"
                      disabled={!stakeAmount || Number.parseFloat(stakeAmount) <= 0}
                      onClick={handleStakeAction}
                    >
                      Stake SOL
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="mb-1.5 block text-xs text-muted-foreground">Amount to Unstake</label>
                      <div className="relative">
                        <input
                          type="number"
                          value={unstakeAmount}
                          onChange={(e) => setUnstakeAmount(e.target.value)}
                          placeholder="0.00"
                          className="w-full rounded-lg border border-border bg-input px-3 py-2.5 pr-14 font-mono text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                          SOL
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs text-muted-foreground">
                        Staked:{" "}
                        <span className="font-mono text-foreground">{mockUserStake.currentStake.toFixed(2)} SOL</span>
                      </p>
                    </div>

                    {/* Quick amounts */}
                    <div className="flex gap-2">
                      {[25, 50, 100].map((amount) => (
                        <button
                          key={amount}
                          onClick={() => setUnstakeAmount(Math.min(amount, mockUserStake.currentStake).toString())}
                          className="flex-1 rounded-lg border border-border bg-secondary/50 px-2 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                        >
                          {amount} SOL
                        </button>
                      ))}
                      <button
                        onClick={() => setUnstakeAmount(mockUserStake.currentStake.toString())}
                        className="flex-1 rounded-lg border border-chart-3/50 bg-chart-3/10 px-2 py-1.5 text-xs font-medium text-chart-3 transition-colors hover:bg-chart-3/20"
                      >
                        Max
                      </button>
                    </div>

                    {/* Warning */}
                    <div className="flex items-start gap-2 rounded-lg border border-chart-3/30 bg-chart-3/5 p-3">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-chart-3" />
                      <p className="text-xs text-chart-3">
                        Unstaking may affect your tier status and access to certain tasks. 7-day cooldown applies.
                      </p>
                    </div>

                    <Button
                      className="w-full bg-transparent"
                      variant="outline"
                      disabled={!unstakeAmount || Number.parseFloat(unstakeAmount) <= 0}
                      onClick={handleStakeAction}
                    >
                      Unstake SOL
                    </Button>
                  </div>
                )}
              </div>

              {/* Staking info card */}
              <div className="rounded-xl border border-border bg-gradient-to-br from-card to-primary/5 p-5">
                <div className="mb-3 flex items-center gap-2">
                  <Info className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-semibold text-card-foreground">Staking Benefits</h3>
                </div>
                <ul className="space-y-2 text-xs text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                    Earn 8.5% APY on staked SOL
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                    Access higher-value tasks
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
                    Build trust with requesters
                  </li>
                  <li className="flex items-start gap-2">
                    <XCircle className="mt-0.5 h-3 w-3 shrink-0 text-destructive" />
                    Risk of slashing for poor work
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Confirm Modal */}
      <ConfirmationModal
        open={showConfirmModal}
        onOpenChange={setShowConfirmModal}
        title={confirmAction === "stake" ? "Confirm Stake" : "Confirm Unstake"}
        description={
          confirmAction === "stake"
            ? `You are about to stake ${stakeAmount} SOL. This will increase your tier access and earning potential.`
            : `You are about to unstake ${unstakeAmount} SOL. A 7-day cooldown will apply before funds are available.`
        }
        variant={confirmAction === "stake" ? "info" : "warning"}
        confirmText={confirmAction === "stake" ? "Stake Now" : "Unstake"}
        onConfirm={handleConfirm}
        loading={isProcessing}
      />
    </div>
  )
}
