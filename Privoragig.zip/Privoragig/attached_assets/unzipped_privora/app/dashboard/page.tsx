"use client"

import { useState } from "react"
import {
  Wallet,
  Coins,
  ClipboardList,
  Star,
  PlusCircle,
  HandCoins,
  TrendingUp,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle2,
  Clock,
  ChevronRight,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"

// Mock data
const stats = [
  {
    label: "Available Balance",
    value: "1,234.56",
    unit: "SOL",
    icon: Wallet,
    change: "+12.3%",
    positive: true,
  },
  {
    label: "Staked Amount",
    value: "500.00",
    unit: "SOL",
    icon: Coins,
    change: "+5.2%",
    positive: true,
  },
  {
    label: "Open Tasks",
    value: "8",
    unit: "tasks",
    icon: ClipboardList,
    change: "3 pending",
    positive: null,
  },
  {
    label: "PrivoraScore",
    value: "94",
    unit: "/100",
    icon: Star,
    change: "+2 pts",
    positive: true,
  },
]

const recentActivity = [
  {
    id: 1,
    type: "task_accepted",
    title: "Task Accepted",
    description: "Data labeling task #1234",
    amount: "+25.00 SOL",
    time: "2 min ago",
    icon: CheckCircle2,
  },
  {
    id: 2,
    type: "payout_released",
    title: "Payout Released",
    description: "Image classification #1201",
    amount: "+45.50 SOL",
    time: "1 hour ago",
    icon: ArrowDownLeft,
  },
  {
    id: 3,
    type: "task_accepted",
    title: "Task Accepted",
    description: "Sentiment analysis #1198",
    amount: "+18.75 SOL",
    time: "3 hours ago",
    icon: CheckCircle2,
  },
  {
    id: 4,
    type: "stake_reward",
    title: "Stake Reward",
    description: "Weekly staking reward",
    amount: "+2.35 SOL",
    time: "1 day ago",
    icon: TrendingUp,
  },
  {
    id: 5,
    type: "payout_released",
    title: "Payout Released",
    description: "Text summarization #1195",
    amount: "+32.00 SOL",
    time: "2 days ago",
    icon: ArrowDownLeft,
  },
]

export default function DashboardPage() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress="7xKp...9mNq" notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-foreground">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome back! Here's your overview.</p>
          </div>

          {/* Stats Row */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => {
              const Icon = stat.icon
              return (
                <div
                  key={stat.label}
                  className="rounded-xl border border-border bg-card p-5 transition-shadow hover:shadow-md"
                >
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-2xl font-bold text-card-foreground">{stat.value}</span>
                    <span className="text-sm text-muted-foreground">{stat.unit}</span>
                  </div>
                  {stat.change && (
                    <div className="mt-2 flex items-center gap-1">
                      {stat.positive !== null && (
                        <ArrowUpRight className={`h-3 w-3 ${stat.positive ? "text-emerald-500" : "text-red-500"}`} />
                      )}
                      {stat.positive === null && <Clock className="h-3 w-3 text-muted-foreground" />}
                      <span
                        className={`text-xs ${
                          stat.positive === true
                            ? "text-emerald-500"
                            : stat.positive === false
                              ? "text-red-500"
                              : "text-muted-foreground"
                        }`}
                      >
                        {stat.change}
                      </span>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Main Grid */}
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Recent Activity Feed */}
            <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-card-foreground">Recent Activity</h2>
                <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                  View All
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-3">
                {recentActivity.map((activity) => {
                  const Icon = activity.icon
                  return (
                    <div
                      key={activity.id}
                      className="flex items-center gap-4 rounded-lg bg-secondary/50 p-3 transition-colors hover:bg-secondary"
                    >
                      <div
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                          activity.type === "payout_released" || activity.type === "stake_reward"
                            ? "bg-emerald-500/10 text-emerald-500"
                            : "bg-primary/10 text-primary"
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-card-foreground">{activity.title}</p>
                        <p className="truncate text-xs text-muted-foreground">{activity.description}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-medium text-emerald-500">{activity.amount}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="rounded-xl border border-border bg-card p-5">
                <h2 className="mb-4 text-lg font-semibold text-card-foreground">Quick Actions</h2>
                <div className="space-y-2">
                  <Button className="w-full justify-start gap-3 rounded-lg" variant="default">
                    <PlusCircle className="h-4 w-4" />
                    Post Task
                  </Button>
                  <Button className="w-full justify-start gap-3 rounded-lg" variant="secondary">
                    <HandCoins className="h-4 w-4" />
                    Take Task
                  </Button>
                  <Button className="w-full justify-start gap-3 rounded-lg bg-transparent" variant="outline">
                    <Coins className="h-4 w-4" />
                    Stake More
                  </Button>
                </div>
              </div>

              {/* Wallet & Stake Mini Card */}
              <div className="rounded-xl border border-border bg-gradient-to-br from-card to-primary/5 p-5">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Wallet className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-card-foreground">Wallet & Stake</h3>
                    <p className="text-xs text-muted-foreground">Manage your funds</p>
                  </div>
                </div>

                <div className="mb-4 space-y-3">
                  <div className="flex items-center justify-between rounded-lg bg-secondary/50 px-3 py-2">
                    <span className="text-xs text-muted-foreground">Available</span>
                    <span className="font-mono text-sm font-medium text-card-foreground">1,234.56 SOL</span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-secondary/50 px-3 py-2">
                    <span className="text-xs text-muted-foreground">Staked</span>
                    <span className="font-mono text-sm font-medium text-primary">500.00 SOL</span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-secondary/50 px-3 py-2">
                    <span className="text-xs text-muted-foreground">Rewards (APY)</span>
                    <span className="font-mono text-sm font-medium text-emerald-500">8.5%</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 rounded-lg" variant="default">
                    Deposit
                  </Button>
                  <Button size="sm" className="flex-1 rounded-lg bg-transparent" variant="outline">
                    Withdraw
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
