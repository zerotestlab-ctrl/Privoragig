import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useMockWallet } from "@/context/auth-context";
import { TrendingUp, Coins, Lock, Unlock, ChevronRight, ArrowUpRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

export default function Stake() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();
  const [stakeAmount, setStakeAmount] = useState("");
  const [activeTab, setActiveTab] = useState<"stake" | "unstake">("stake");
  const [staking, setStaking] = useState(false);

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user) return null;

  const handleStake = () => {
    if (stakeAmount && parseFloat(stakeAmount) > 0 && parseFloat(stakeAmount) <= user.balance) {
      setStaking(true);
      setTimeout(() => {
        setStaking(false);
        setStakeAmount("");
      }, 1500);
    }
  };

  const maxStake = user.balance;
  const apr = 8.5;
  const estimatedAnnualReward = (parseFloat(stakeAmount) || 0) * (apr / 100);
  const estimatedMonthlyReward = estimatedAnnualReward / 12;

  const stakingTiers = [
    { amount: 100, apy: "6.5%", multiplier: "1x" },
    { amount: 500, apy: "8.5%", multiplier: "1.5x" },
    { amount: 1000, apy: "10.5%", multiplier: "2x" },
    { amount: 5000, apy: "12.5%", multiplier: "3x" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <div className="max-w-4xl">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-card-foreground mb-2">Stake & Earn</h1>
              <p className="text-muted-foreground">Lock your SOL to boost reputation and earn passive rewards.</p>
            </div>

            <div className="grid gap-6 lg:grid-cols-3">
              {/* Main Staking Card */}
              <div className="lg:col-span-2 space-y-6">
                <Card className="border-border bg-card">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Stake SOL</CardTitle>
                        <CardDescription>Lock tokens to earn rewards</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={activeTab === "stake" ? "default" : "secondary"} 
                          className="cursor-pointer" onClick={() => setActiveTab("stake")}>
                          <Lock className="h-3 w-3 mr-1" />
                          Stake
                        </Badge>
                        <Badge variant={activeTab === "unstake" ? "default" : "secondary"}
                          className="cursor-pointer" onClick={() => setActiveTab("unstake")}>
                          <Unlock className="h-3 w-3 mr-1" />
                          Unstake
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {activeTab === "stake" ? (
                      <>
                        <Alert className="bg-primary/5 border-primary/10">
                          <TrendingUp className="h-4 w-4 text-primary" />
                          <AlertTitle>Earn Passive Income</AlertTitle>
                          <AlertDescription className="text-muted-foreground">
                            Your staked SOL earns {apr}% APY. Higher stakes unlock better rates.
                          </AlertDescription>
                        </Alert>

                        <div className="space-y-2">
                          <label className="block text-sm font-medium text-card-foreground">Amount to Stake (SOL)</label>
                          <div className="flex gap-2">
                            <Input
                              type="number"
                              value={stakeAmount}
                              onChange={(e) => setStakeAmount(e.target.value)}
                              placeholder="0.00"
                              step="0.01"
                              min="0"
                              max={maxStake}
                              className="bg-secondary/30"
                              disabled={staking}
                            />
                            <Button 
                              variant="outline" 
                              onClick={() => setStakeAmount(maxStake.toString())}
                              disabled={staking}
                            >
                              Max
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">Available: {maxStake.toFixed(2)} SOL</p>
                        </div>

                        {stakeAmount && parseFloat(stakeAmount) > 0 && (
                          <div className="space-y-3 p-4 rounded-lg bg-secondary/50">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Staking Amount</span>
                              <span className="font-mono font-semibold">{parseFloat(stakeAmount).toFixed(2)} SOL</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Annual Reward (Est.)</span>
                              <span className="font-mono font-semibold text-emerald-500">
                                +{estimatedAnnualReward.toFixed(2)} SOL
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Monthly Reward (Est.)</span>
                              <span className="font-mono font-semibold text-emerald-500">
                                +{estimatedMonthlyReward.toFixed(3)} SOL
                              </span>
                            </div>
                            <div className="pt-2 border-t border-border flex justify-between text-sm font-medium">
                              <span>New Total Balance</span>
                              <span className="font-mono text-primary">
                                {(user.balance - parseFloat(stakeAmount || "0")).toFixed(2)} SOL
                              </span>
                            </div>
                          </div>
                        )}

                        <Button 
                          onClick={handleStake}
                          className="w-full"
                          disabled={!stakeAmount || parseFloat(stakeAmount) <= 0 || parseFloat(stakeAmount) > maxStake || staking}
                        >
                          {staking ? "Confirming Stake..." : "Stake Now"}
                        </Button>
                      </>
                    ) : (
                      <>
                        <Alert className="bg-chart-3/5 border-chart-3/10">
                          <Unlock className="h-4 w-4 text-chart-3" />
                          <AlertTitle>Unstake SOL</AlertTitle>
                          <AlertDescription className="text-muted-foreground">
                            Unlock your staked SOL. There's no penalty for unstaking.
                          </AlertDescription>
                        </Alert>

                        <div className="space-y-2">
                          <label className="block text-sm font-medium text-card-foreground">Amount to Unstake (SOL)</label>
                          <div className="flex gap-2">
                            <Input
                              type="number"
                              placeholder="0.00"
                              step="0.01"
                              min="0"
                              max={user.staked}
                              className="bg-secondary/30"
                            />
                            <Button 
                              variant="outline"
                              onClick={() => {}}
                            >
                              Max
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">Currently Staked: {user.staked.toFixed(2)} SOL</p>
                        </div>

                        <Button className="w-full" variant="secondary">
                          Unstake Now
                        </Button>
                      </>
                    )}
                  </CardContent>
                </Card>

                {/* Staking Tiers */}
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-base">Staking Tiers</CardTitle>
                    <CardDescription>Unlock higher APY with larger stakes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {stakingTiers.map((tier, idx) => (
                        <div
                          key={idx}
                          className="p-4 rounded-lg border border-border bg-secondary/30 hover:border-primary/50 transition-colors"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="text-sm font-semibold text-card-foreground">{tier.amount.toLocaleString()} SOL+</p>
                              <p className="text-xs text-muted-foreground mt-1">APY: {tier.apy}</p>
                            </div>
                            <Badge variant="secondary" className="text-xs">{tier.multiplier}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Sidebar */}
              <div className="space-y-6">
                {/* Staking Summary */}
                <Card className="border-border bg-gradient-to-br from-card to-primary/5">
                  <CardHeader>
                    <CardTitle className="text-base">Your Staking</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Total Staked</p>
                      <p className="text-2xl font-bold text-card-foreground flex items-center gap-1">
                        <Coins className="h-5 w-5 text-primary" />
                        {user.staked.toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">SOL</p>
                    </div>

                    <div className="p-3 rounded-lg bg-secondary/50 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Pending Rewards</span>
                        <span className="text-emerald-500 font-semibold">{(user.staked * 0.085 / 12).toFixed(3)} SOL</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Est. Monthly</span>
                        <span className="text-emerald-500 font-semibold">{(user.staked * 0.085 / 12).toFixed(3)} SOL</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Est. Annual</span>
                        <span className="text-emerald-500 font-semibold">{(user.staked * 0.085).toFixed(2)} SOL</span>
                      </div>
                    </div>

                    <Button className="w-full" variant="outline" size="sm">
                      <ArrowUpRight className="h-3.5 w-3.5 mr-1.5" />
                      View Rewards History
                    </Button>
                  </CardContent>
                </Card>

                {/* Reputation Boost */}
                <Card className="border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-base">Reputation Boost</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm">
                      <p className="text-muted-foreground mb-2">Your current stake multiplier:</p>
                      <div className="text-2xl font-bold text-primary">1.5x</div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Higher stakes increase your reputation score and unlock premium task opportunities.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
