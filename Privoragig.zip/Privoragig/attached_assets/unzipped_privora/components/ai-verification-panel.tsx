"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ConfirmationModal } from "@/components/confirmation-modal"
import { Bot, CheckCircle, XCircle, Clock, Shield, Eye, MessageSquare, Coins, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface AIVerificationResult {
  score: number // 0-100
  verdict: "pass" | "fail" | "pending"
  comments: string[]
  recommendedPayout: number // percentage 0-100
  verifiedAt?: string
  processingTime?: string
}

interface AIVerificationPanelProps {
  result: AIVerificationResult
  rewardAmount: number
  onAcceptAndRelease: () => void
  onRequestHumanReview: () => void
}

export function AIVerificationPanel({
  result,
  rewardAmount,
  onAcceptAndRelease,
  onRequestHumanReview,
}: AIVerificationPanelProps) {
  const [showReleaseModal, setShowReleaseModal] = useState(false)
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [isReleasing, setIsReleasing] = useState(false)
  const [isRequesting, setIsRequesting] = useState(false)

  const isPassing = result.verdict === "pass"
  const isPending = result.verdict === "pending"
  const calculatedPayout = (rewardAmount * result.recommendedPayout) / 100

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-primary"
    if (score >= 60) return "text-chart-3"
    if (score >= 40) return "text-yellow-500"
    return "text-destructive"
  }

  const getScoreBgColor = (score: number) => {
    if (score >= 80) return "bg-primary"
    if (score >= 60) return "bg-chart-3"
    if (score >= 40) return "bg-yellow-500"
    return "bg-destructive"
  }

  const handleAcceptAndRelease = async () => {
    setIsReleasing(true)
    // Simulate async operation
    await new Promise((r) => setTimeout(r, 1500))
    onAcceptAndRelease()
    setIsReleasing(false)
    setShowReleaseModal(false)
  }

  const handleRequestReview = async () => {
    setIsRequesting(true)
    await new Promise((r) => setTimeout(r, 1000))
    onRequestHumanReview()
    setIsRequesting(false)
    setShowReviewModal(false)
  }

  return (
    <>
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        {/* Header */}
        <div
          className={cn(
            "flex items-center gap-3 px-6 py-4 border-b border-border",
            isPending ? "bg-secondary/50" : isPassing ? "bg-primary/5" : "bg-destructive/5",
          )}
        >
          <div
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-full",
              isPending ? "bg-secondary" : isPassing ? "bg-primary/10" : "bg-destructive/10",
            )}
          >
            {isPending ? (
              <Clock className="h-5 w-5 text-muted-foreground animate-pulse" />
            ) : isPassing ? (
              <CheckCircle className="h-5 w-5 text-primary" />
            ) : (
              <XCircle className="h-5 w-5 text-destructive" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">AI Verification</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {isPending ? "Analyzing submission..." : `Completed ${result.verifiedAt || "just now"}`}
            </p>
          </div>
          {!isPending && result.processingTime && (
            <span className="rounded-full bg-secondary px-2 py-1 text-xs text-muted-foreground">
              {result.processingTime}
            </span>
          )}
        </div>

        {/* Score Section */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-muted-foreground">Quality Score</span>
            <span className={cn("text-3xl font-bold tabular-nums", getScoreColor(result.score))}>
              {result.score}
              <span className="text-lg text-muted-foreground">/100</span>
            </span>
          </div>

          {/* Score Bar */}
          <div className="h-3 rounded-full bg-secondary overflow-hidden">
            <div
              className={cn("h-full rounded-full transition-all duration-500", getScoreBgColor(result.score))}
              style={{ width: `${result.score}%` }}
            />
          </div>

          {/* Score Labels */}
          <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <span>Poor</span>
            <span>Fair</span>
            <span>Good</span>
            <span>Excellent</span>
          </div>
        </div>

        {/* Verdict Badge */}
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Verdict</span>
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium",
                isPending
                  ? "bg-secondary text-muted-foreground"
                  : isPassing
                    ? "bg-primary/10 text-primary"
                    : "bg-destructive/10 text-destructive",
              )}
            >
              {isPending ? (
                <>
                  <Clock className="h-3.5 w-3.5" />
                  Pending
                </>
              ) : isPassing ? (
                <>
                  <CheckCircle className="h-3.5 w-3.5" />
                  Pass
                </>
              ) : (
                <>
                  <XCircle className="h-3.5 w-3.5" />
                  Fail
                </>
              )}
            </span>
          </div>
        </div>

        {/* AI Comments */}
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center gap-2 mb-3">
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium text-foreground">Analysis Comments</span>
          </div>
          <ul className="space-y-2">
            {result.comments.map((comment, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {comment}
              </li>
            ))}
          </ul>
        </div>

        {/* Recommended Payout */}
        <div className="px-6 py-4 border-b border-border bg-secondary/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Coins className="h-4 w-4 text-chart-3" />
              <span className="text-sm text-muted-foreground">Recommended Payout</span>
            </div>
            <div className="text-right">
              <span className="text-lg font-semibold text-foreground">{result.recommendedPayout}%</span>
              <p className="text-xs text-muted-foreground">
                {calculatedPayout.toFixed(2)} USDC of {rewardAmount} USDC
              </p>
            </div>
          </div>

          {/* Payout calculation breakdown */}
          <div className="mt-3 flex items-center gap-2 rounded-lg bg-card p-3 text-sm">
            <span className="text-muted-foreground">Full Reward</span>
            <span className="font-mono text-foreground">{rewardAmount} USDC</span>
            <ArrowRight className="h-3 w-3 text-muted-foreground" />
            <span className="text-muted-foreground">x {result.recommendedPayout}%</span>
            <ArrowRight className="h-3 w-3 text-muted-foreground" />
            <span className="font-mono font-semibold text-primary">{calculatedPayout.toFixed(2)} USDC</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-6 space-y-3">
          <Button
            onClick={() => setShowReleaseModal(true)}
            className="w-full rounded-lg"
            size="lg"
            disabled={isPending}
          >
            <CheckCircle className="mr-2 h-4 w-4" />
            Accept Result & Release Payout
          </Button>

          <Button
            onClick={() => setShowReviewModal(true)}
            variant="outline"
            className="w-full rounded-lg bg-transparent"
            size="lg"
            disabled={isPending}
          >
            <Eye className="mr-2 h-4 w-4" />
            Request Human Review
          </Button>

          {/* Escrow hold notice */}
          <div className="flex items-start gap-2 rounded-lg bg-chart-3/10 p-3 text-xs text-chart-3">
            <Shield className="mt-0.5 h-4 w-4 shrink-0" />
            <p>
              Requesting human review will place funds in escrow hold until a moderator reviews the submission. This
              typically takes 24-48 hours.
            </p>
          </div>
        </div>
      </div>

      {/* Release Payout Modal */}
      <ConfirmationModal
        open={showReleaseModal}
        onOpenChange={setShowReleaseModal}
        title="Release Payout"
        description={`You're about to release ${calculatedPayout.toFixed(2)} USDC (${result.recommendedPayout}% of ${rewardAmount} USDC) to the worker based on the AI verification score. This action cannot be undone.`}
        confirmLabel={isReleasing ? "Releasing..." : "Confirm & Release"}
        cancelLabel="Cancel"
        onConfirm={handleAcceptAndRelease}
        variant="success"
        loading={isReleasing}
      />

      {/* Human Review Modal */}
      <ConfirmationModal
        open={showReviewModal}
        onOpenChange={setShowReviewModal}
        title="Request Human Review"
        description="Funds will be held in escrow while a human moderator reviews the submission. You'll be notified once the review is complete. Average review time is 24-48 hours."
        confirmLabel={isRequesting ? "Requesting..." : "Request Review"}
        cancelLabel="Cancel"
        onConfirm={handleRequestReview}
        variant="warning"
        loading={isRequesting}
      />
    </>
  )
}
