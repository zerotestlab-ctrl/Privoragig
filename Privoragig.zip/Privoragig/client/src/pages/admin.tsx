import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { useMockWallet } from "@/context/auth-context";
import { BarChart3, Users, Shield, AlertTriangle, TrendingUp, CheckCircle2, Clock, XCircle, Eye, Trash2, Ban } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Admin() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user) return null;

  // Mock admin stats
  const stats = [
    { label: "Total Tasks", value: "1,284", change: "+12%", icon: BarChart3, trend: "up" },
    { label: "Active Users", value: "542", change: "+8%", icon: Users, trend: "up" },
    { label: "Pending Disputes", value: "23", change: "+3", icon: AlertTriangle, trend: "up" },
    { label: "System Health", value: "99.8%", change: "Normal", icon: Shield, trend: "stable" },
  ];

  // Mock tasks needing moderation
  const tasks = [
    { id: 1, title: "Translate Document", requester: "User#4521", status: "flagged", reason: "Quality below threshold" },
    { id: 2, title: "Data Classification", requester: "User#3891", status: "review", reason: "Duplicate submission" },
    { id: 3, title: "Content Research", requester: "User#5021", status: "spam", reason: "Potential spam content" },
  ];

  // Mock disputes
  const disputes = [
    { id: 1, task: "Image Tagging #1045", user: "User#2891", status: "open", created: "2 hours ago" },
    { id: 2, task: "Video Transcription #1042", user: "User#3142", status: "in_review", created: "6 hours ago" },
    { id: 3, task: "Translation #1038", user: "User#1823", status: "resolved", created: "1 day ago" },
  ];

  // Mock users under review
  const users = [
    { id: 1, wallet: "User#4521", tasks: 45, rating: 7.2, status: "flagged", reason: "Low quality scores" },
    { id: 2, wallet: "User#3891", tasks: 128, rating: 9.1, status: "active", reason: "Normal" },
    { id: 3, wallet: "User#5021", tasks: 12, rating: 3.4, status: "suspended", reason: "Multiple violations" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <div className="max-w-7xl">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-card-foreground mb-2">Admin Dashboard</h1>
              <p className="text-muted-foreground">Monitor system health, moderate content, and manage disputes.</p>
            </div>

            {/* Alert */}
            <Alert className="mb-6 bg-chart-3/5 border-chart-3/20">
              <AlertTriangle className="h-4 w-4 text-chart-3" />
              <AlertTitle>23 Active Disputes</AlertTitle>
              <AlertDescription className="text-muted-foreground">
                {disputes.filter(d => d.status === "open").length} require immediate attention
              </AlertDescription>
            </Alert>

            {/* Stats Grid */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
              {stats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <Card key={stat.label} className="border-border bg-card">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
                          <p className="text-2xl font-bold text-card-foreground">{stat.value}</p>
                          <p className={`text-xs mt-2 ${stat.trend === "up" ? "text-red-500" : "text-emerald-500"}`}>
                            {stat.change}
                          </p>
                        </div>
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Main Content Tabs */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <Tabs defaultValue="tasks">
                  <TabsList className="bg-secondary/50 grid w-full grid-cols-3">
                    <TabsTrigger value="tasks">Tasks ({tasks.length})</TabsTrigger>
                    <TabsTrigger value="disputes">Disputes ({disputes.length})</TabsTrigger>
                    <TabsTrigger value="users">Users</TabsTrigger>
                  </TabsList>

                  {/* Tasks Tab */}
                  <TabsContent value="tasks" className="space-y-4 mt-4">
                    <div className="space-y-3">
                      {tasks.map((task) => (
                        <div
                          key={task.id}
                          className="p-4 rounded-lg border border-border/50 bg-secondary/30 flex items-center justify-between"
                        >
                          <div className="flex-1">
                            <h3 className="text-sm font-semibold text-card-foreground">{task.title}</h3>
                            <p className="text-xs text-muted-foreground mt-1">
                              {task.requester} • {task.reason}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            {task.status === "flagged" && (
                              <Badge className="bg-red-500/10 text-red-500 hover:bg-red-500/20">Flagged</Badge>
                            )}
                            {task.status === "review" && (
                              <Badge className="bg-chart-3/10 text-chart-3 hover:bg-chart-3/20">Review</Badge>
                            )}
                            {task.status === "spam" && (
                              <Badge variant="destructive" className="bg-red-500/10 text-red-500 hover:bg-red-500/20">Spam</Badge>
                            )}
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-red-500 hover:text-red-600">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  {/* Disputes Tab */}
                  <TabsContent value="disputes" className="space-y-4 mt-4">
                    <div className="space-y-3">
                      {disputes.map((dispute) => (
                        <div
                          key={dispute.id}
                          className="p-4 rounded-lg border border-border/50 bg-secondary/30 flex items-center justify-between"
                        >
                          <div className="flex-1">
                            <h3 className="text-sm font-semibold text-card-foreground">{dispute.task}</h3>
                            <p className="text-xs text-muted-foreground mt-1">
                              {dispute.user} • Created {dispute.created}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            {dispute.status === "open" && (
                              <Badge className="bg-red-500/10 text-red-500 hover:bg-red-500/20">Open</Badge>
                            )}
                            {dispute.status === "in_review" && (
                              <Badge className="bg-primary/10 text-primary hover:bg-primary/20">In Review</Badge>
                            )}
                            {dispute.status === "resolved" && (
                              <Badge className="bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20">Resolved</Badge>
                            )}
                            <Button size="sm" variant="default" className="h-8 px-3 text-xs gap-1">
                              <Eye className="h-3 w-3" />
                              Review
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  {/* Users Tab */}
                  <TabsContent value="users" className="space-y-4 mt-4">
                    <div className="space-y-3">
                      {users.map((user) => (
                        <div
                          key={user.id}
                          className="p-4 rounded-lg border border-border/50 bg-secondary/30 flex items-center justify-between"
                        >
                          <div className="flex-1">
                            <h3 className="text-sm font-semibold text-card-foreground">{user.wallet}</h3>
                            <p className="text-xs text-muted-foreground mt-1">
                              {user.tasks} tasks • Rating: {user.rating}/10
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">{user.reason}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {user.status === "flagged" && (
                              <Badge className="bg-chart-3/10 text-chart-3 hover:bg-chart-3/20">Flagged</Badge>
                            )}
                            {user.status === "active" && (
                              <Badge className="bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20">Active</Badge>
                            )}
                            {user.status === "suspended" && (
                              <Badge variant="destructive" className="bg-red-500/10 text-red-500 hover:bg-red-500/20">Suspended</Badge>
                            )}
                            <Button size="sm" variant="outline" className="h-8 px-2 text-xs gap-1">
                              <Eye className="h-3 w-3" />
                              View
                            </Button>
                            {user.status !== "suspended" && (
                              <Button size="sm" variant="ghost" className="h-8 px-2 text-xs gap-1 text-red-500 hover:text-red-600">
                                <Ban className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardHeader>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
