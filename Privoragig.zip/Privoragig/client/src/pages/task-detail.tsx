import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { tasks } from "@/data/tasks";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useMockWallet } from "@/context/auth-context";
import { CheckCircle2, UploadCloud, ArrowLeft, Clock, Coins, Shield, AlertCircle, Loader2, X } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { aiVerify, VerificationResult } from "@/lib/ai-verify";

export default function TaskDetail() {
  const [match, params] = useRoute("/task/:id");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();
  const [submitted, setSubmitted] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [submissionText, setSubmissionText] = useState("");
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);

  // Redirect if not logged in
  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user || !match) return null;

  const task = tasks.find(t => t.id === params!.id);
  
  if (!task) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Task not found</h2>
          <Button className="mt-4" onClick={() => setLocation("/marketplace")}>
            Back to Marketplace
          </Button>
        </div>
      </div>
    );
  }

  const handleSubmit = async () => {
    setVerifying(true);
    const result = await aiVerify(submissionText);
    setVerificationResult(result);
    setVerifying(false);
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <Button 
            variant="ghost" 
            className="mb-6 gap-2 pl-0 hover:pl-2 transition-all" 
            onClick={() => setLocation("/marketplace")}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Marketplace
          </Button>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Left Column - Task Details */}
            <div className="lg:col-span-2 space-y-6">
              <div className="rounded-xl border border-border bg-card p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant={task.type === "micro" ? "secondary" : "default"} className={task.type === "micro" ? "bg-primary/10 text-primary hover:bg-primary/20" : "bg-chart-3/10 text-chart-3 hover:bg-chart-3/20"}>
                        {task.type === "micro" ? "Micro Task" : "Macro Task"}
                      </Badge>
                      {task.aiRequired && (
                        <Badge variant="outline" className="border-primary/20 text-muted-foreground">
                          AI Verified
                        </Badge>
                      )}
                    </div>
                    <h1 className="text-2xl font-bold text-card-foreground">{task.title}</h1>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center justify-end gap-1 text-primary text-xl font-bold font-mono">
                      <Coins className="h-5 w-5" />
                      {task.reward.toFixed(2)} SOL
                    </div>
                    <div className="text-sm text-muted-foreground">Reward</div>
                  </div>
                </div>

                <div className="prose prose-invert max-w-none mb-8">
                  <h3 className="text-lg font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground leading-relaxed">{task.description}</p>
                  
                  <h3 className="text-lg font-semibold mt-6 mb-2">Requirements</h3>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1">
                    <li>Complete within {task.eta}</li>
                    <li>Minimum quality score of 8.0 required</li>
                    {task.stakeRequired > 0 && <li>Stake {task.stakeRequired} SOL as collateral</li>}
                  </ul>
                </div>

                <div className="flex flex-wrap gap-2">
                  {task.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="rounded-full">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Submission Area */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle>Submission</CardTitle>
                  <CardDescription>Submit your work for verification</CardDescription>
                </CardHeader>
                <CardContent>
                  {submitted ? (
                    <div className="space-y-6">
                      {verificationResult && (
                        <>
                          <div className={`flex flex-col items-center justify-center py-8 text-center rounded-lg ${verificationResult.passed ? 'bg-emerald-500/5 border border-emerald-500/20' : 'bg-red-500/5 border border-red-500/20'} animate-in fade-in zoom-in duration-500`}>
                            <div className={`h-16 w-16 rounded-full flex items-center justify-center mb-4 ${verificationResult.passed ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                              <CheckCircle2 className={`h-8 w-8 ${verificationResult.passed ? 'text-emerald-500' : 'text-red-500'}`} />
                            </div>
                            <h3 className="text-xl font-bold text-card-foreground mb-2">
                              {verificationResult.passed ? 'Verification Passed!' : 'Verification Failed'}
                            </h3>
                            <p className="text-muted-foreground max-w-md mx-auto mb-4">
                              {verificationResult.comment}
                            </p>
                            <div className="text-center mb-6">
                              <p className="text-sm text-muted-foreground mb-1">Quality Score</p>
                              <p className={`text-3xl font-bold ${verificationResult.passed ? 'text-emerald-500' : 'text-red-500'}`}>
                                {verificationResult.score}%
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <Button 
                              variant="outline" 
                              className="flex-1"
                              onClick={() => {
                                setSubmitted(false);
                                setVerificationResult(null);
                                setSubmissionText("");
                              }}
                            >
                              <X className="h-4 w-4 mr-2" />
                              Edit Submission
                            </Button>
                            {verificationResult.passed && (
                              <Button 
                                className="flex-1"
                                onClick={() => setLocation("/dashboard")}
                              >
                                Return to Dashboard
                              </Button>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Alert className="bg-primary/5 border-primary/10">
                        <AlertCircle className="h-4 w-4 text-primary" />
                        <AlertTitle>Instruction</AlertTitle>
                        <AlertDescription className="text-muted-foreground">
                          Please provide your result below. Your submission will be verified by our AI agents.
                        </AlertDescription>
                      </Alert>
                      
                      <Textarea 
                        placeholder="Enter your submission details here..." 
                        className="min-h-[200px] bg-secondary/30 resize-y"
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        disabled={verifying}
                      />
                      
                      <div className="flex items-center justify-between pt-4">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <UploadCloud className="h-4 w-4" />
                          <span>Attach files (optional)</span>
                        </div>
                        <Button 
                          onClick={handleSubmit}
                          size="lg"
                          className="min-w-[150px]"
                          disabled={!submissionText.trim() || verifying}
                        >
                          {verifying && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                          {verifying ? "Verifying..." : "Submit Result"}
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Stats & Info */}
            <div className="space-y-6">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-base">Task Status</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Time Remaining</span>
                    <div className="flex items-center gap-1.5 text-sm font-medium">
                      <Clock className="h-4 w-4 text-primary" />
                      {task.eta}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Requester</span>
                    <span className="text-sm font-medium">{task.requesterName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Reputation</span>
                    <div className="flex items-center gap-1 text-sm font-medium text-chart-3">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {task.requesterRating.toFixed(1)}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-base">Staking Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-lg bg-secondary/50 flex items-start gap-3">
                    <Shield className="h-5 w-5 text-chart-3 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Collateral Required</p>
                      <p className="text-xs text-muted-foreground">
                        {task.stakeRequired} SOL will be locked until successful completion.
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Your Staked Balance</span>
                    <span className="font-mono">{user.staked.toFixed(2)} SOL</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
