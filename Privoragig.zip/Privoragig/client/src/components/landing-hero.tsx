import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Zap, Shield, Coins, Wallet, Check } from "lucide-react"
import { WalletModal } from "@/components/wallet-modal"
import { useMockWallet } from "@/context/auth-context"

interface FeatureCardProps {
  icon: React.ReactNode
  title: string
  description: string
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="group rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary/20">
        {icon}
      </div>
      <h3 className="mb-1.5 text-base font-semibold text-card-foreground">{title}</h3>
      <p className="text-sm leading-relaxed text-muted-foreground">{description}</p>
    </div>
  )
}

export function LandingHero() {
  const [walletModalOpen, setWalletModalOpen] = useState(false)
  const { user, login } = useMockWallet()

  const handleWalletConnect = (type: "phantom" | "mock" | "guest", address?: string) => {
    login(type, address)
    setWalletModalOpen(false)
  }

  return (
    <section className="relative overflow-hidden min-h-[calc(100vh-64px)] flex flex-col justify-center">
      {/* Subtle background glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-0 h-[500px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-4xl px-6 py-20 text-center">
        {/* Hero content */}
        <div className="mb-16">
          <h1 className="mb-4 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Privora <span className="text-primary">—</span> Private work. Trusted proofs.
          </h1>
          <p className="mx-auto mb-8 max-w-xl text-pretty text-lg text-muted-foreground">
            A Solana-native marketplace with AI verification and staking-based quality.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium text-primary">
                    {user.type === "guest" ? "Guest Mode" : user.wallet}
                  </span>
                </div>
                <Button size="lg" className="rounded-full px-6 font-medium">
                  Enter App
                </Button>
              </div>
            ) : (
              <Button size="lg" className="rounded-full px-6 font-medium" onClick={() => setWalletModalOpen(true)}>
                <Wallet className="mr-2 h-4 w-4" />
                Try Demo
              </Button>
            )}
            <Button variant="outline" size="lg" className="rounded-full px-6 font-medium bg-transparent">
              Whitepaper
            </Button>
          </div>
        </div>

        {/* Feature cards */}
        <div className="grid gap-4 sm:grid-cols-3 text-left">
          <FeatureCard
            icon={<Zap className="h-5 w-5" />}
            title="Instant Solana Payouts"
            description="Get paid immediately upon task completion with low-fee Solana transactions."
          />
          <FeatureCard
            icon={<Shield className="h-5 w-5" />}
            title="AI Verification"
            description="Automated quality checks ensure deliverables meet standards before release."
          />
          <FeatureCard
            icon={<Coins className="h-5 w-5" />}
            title="Staking for Quality"
            description="Contributors stake tokens to signal commitment and earn reputation rewards."
          />
        </div>
      </div>

      <WalletModal open={walletModalOpen} onOpenChange={setWalletModalOpen} onConnect={handleWalletConnect} />
    </section>
  )
}
