import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { TopNav } from "@/components/top-nav";
import { Sidebar } from "@/components/sidebar";
import { useMockWallet } from "@/context/auth-context";
import { Clock, CheckCircle2, AlertCircle, Eye, Download, MessageSquare } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MyTasks() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user } = useMockWallet();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  if (!user) return null;

  const myTasks = [
    {
      id: 1,
      title: "Translate Legal Document",
      description: "Translate 5-page legal agreement from Spanish to English",
      reward: 0.15,
      status: "in_review",
      submittedAt: "2 hours ago",
      quality: null,
      deadline: "2 days",
    },
    {
      id: 2,
      title: "Summarize Private Report",
      description: "Create a 500-word executive summary of quarterly earnings report",
      reward: 0.09,
      status: "completed",
      submittedAt: "1 day ago",
      quality: 9.2,
      deadline: "Done",
    },
    {
      id: 3,
      title: "Data Classification",
      description: "Classify 100 product reviews by sentiment and category",
      reward: 0.22,
      status: "in_review",
      submittedAt: "6 hours ago",
      quality: null,
      deadline: "1 day",
    },
    {
      id: 4,
      title: "Image Tagging",
      description: "Tag 50 images with relevant metadata and descriptions",
      reward: 0.18,
      status: "completed",
      submittedAt: "3 days ago",
      quality: 8.7,
      deadline: "Done",
    },
    {
      id: 5,
      title: "Content Research",
      description: "Research and compile information on emerging AI trends",
      reward: 0.35,
      status: "pending_payment",
      submittedAt: "12 hours ago",
      quality: 9.5,
      deadline: "Paid",
    },
    {
      id: 6,
      title: "Video Transcription",
      description: "Transcribe 30-minute video conference with timestamps",
      reward: 0.27,
      status: "rejected",
      submittedAt: "2 days ago",
      quality: 6.8,
      deadline: "Rejected",
    },
  ];

  const filteredTasks = activeTab === "all" 
    ? myTasks 
    : myTasks.filter(t => {
        if (activeTab === "in_progress") return ["in_review", "pending_payment"].includes(t.status);
        return t.status === activeTab;
      });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_review":
        return <Badge variant="secondary" className="bg-primary/10 text-primary">In Review</Badge>;
      case "completed":
        return <Badge className="bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20">Completed</Badge>;
      case "pending_payment":
        return <Badge className="bg-chart-3/10 text-chart-3 hover:bg-chart-3/20">Pending Payment</Badge>;
      case "rejected":
        return <Badge variant="destructive" className="bg-red-500/10 text-red-500 hover:bg-red-500/20">Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "in_review":
        return <Clock className="h-5 w-5 text-primary" />;
      case "completed":
      case "pending_payment":
        return <CheckCircle2 className="h-5 w-5 text-emerald-500" />;
      case "rejected":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TopNav isWalletConnected={true} walletAddress={user.wallet} notificationCount={3} />

      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className="flex-1 p-6">
          <div className="max-w-5xl">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-card-foreground mb-2">My Tasks</h1>
              <p className="text-muted-foreground">Track submissions, reviews, and earnings from your completed work.</p>
            </div>

            {/* Summary Cards */}
            <div className="grid gap-4 sm:grid-cols-4 mb-6">
              <Card className="border-border bg-card">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Submitted</p>
                    <p className="text-2xl font-bold text-card-foreground">{myTasks.length}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border bg-card">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">In Review</p>
                    <p className="text-2xl font-bold text-primary">{myTasks.filter(t => t.status === "in_review").length}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border bg-card">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Completed</p>
                    <p className="text-2xl font-bold text-emerald-500">{myTasks.filter(t => t.status === "completed").length}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border bg-card">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Earned</p>
                    <p className="text-2xl font-bold text-primary">
                      {myTasks.filter(t => ["completed", "pending_payment"].includes(t.status))
                        .reduce((sum, t) => sum + t.reward, 0)
                        .toFixed(2)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tabs */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="bg-secondary/50 grid w-full grid-cols-4">
                    <TabsTrigger value="all">All Tasks</TabsTrigger>
                    <TabsTrigger value="in_progress">In Progress</TabsTrigger>
                    <TabsTrigger value="completed">Completed</TabsTrigger>
                    <TabsTrigger value="rejected">Rejected</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map((task) => (
                      <div
                        key={task.id}
                        className="p-4 rounded-lg border border-border/50 bg-secondary/30 hover:border-primary/30 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-3 mb-2">
                              {getStatusIcon(task.status)}
                              <h3 className="text-sm font-semibold text-card-foreground truncate">{task.title}</h3>
                            </div>
                            <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{task.description}</p>

                            <div className="flex flex-wrap items-center gap-3">
                              <span className="text-xs text-muted-foreground">
                                Submitted {task.submittedAt}
                              </span>
                              {task.quality !== null && (
                                <span className="text-xs font-medium">
                                  Quality: <span className="text-primary">{task.quality}/10</span>
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-3 shrink-0">
                            <div className="text-right">
                              <p className="text-sm font-semibold text-card-foreground">{task.reward} SOL</p>
                              {getStatusBadge(task.status)}
                            </div>
                            <div className="flex gap-2 text-xs">
                              {["in_review", "pending_payment"].includes(task.status) && (
                                <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1">
                                  <Eye className="h-3 w-3" />
                                  View
                                </Button>
                              )}
                              {task.status === "rejected" && (
                                <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1">
                                  <MessageSquare className="h-3 w-3" />
                                  Feedback
                                </Button>
                              )}
                              {task.status === "completed" && (
                                <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1">
                                  <Download className="h-3 w-3" />
                                  Receipt
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No tasks in this category</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
