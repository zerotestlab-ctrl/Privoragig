import { Task } from "@/components/task-card";

export const tasks: Task[] = [
  {
    id: "1",
    title: "Summarize an article",
    description: "Read the provided article about blockchain scalability solutions and provide a concise 200-word summary highlighting key points.",
    type: "micro",
    reward: 1.2,
    stakeRequired: 0,
    eta: "30 min",
    tags: ["Writing", "Blockchain", "Summary"],
    aiRequired: true,
    requesterRating: 4.8,
    requesterName: "CryptoNews Daily"
  },
  {
    id: "2",
    title: "Write a product description",
    description: "Create a compelling product description for a new DeFi wallet app. Focus on security features and ease of use.",
    type: "micro",
    reward: 4.5,
    stakeRequired: 3,
    eta: "2 hours",
    tags: ["Copywriting", "Marketing", "DeFi"],
    aiRequired: false,
    requesterRating: 4.5,
    requesterName: "WalletX Team"
  },
  {
    id: "3",
    title: "Review a smart contract",
    description: "Audit a Solidity smart contract for potential security vulnerabilities, gas optimization, and logic errors. Report required.",
    type: "macro",
    reward: 15.0,
    stakeRequired: 10,
    eta: "2 days",
    tags: ["Development", "Security", "Solidity"],
    aiRequired: true,
    requesterRating: 5.0,
    requesterName: "SecureChain DAO"
  }
];
