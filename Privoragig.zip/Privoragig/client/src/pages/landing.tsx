import { LandingHero } from "@/components/landing-hero";
import { TopNav } from "@/components/top-nav";
import { useState } from "react";
import { WalletModal } from "@/components/wallet-modal";
import { useMockWallet } from "@/context/auth-context";

export default function Landing() {
  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const { user, login } = useMockWallet();

  const handleWalletConnect = (type: "phantom" | "mock" | "guest", address?: string) => {
    login(type, address);
    setWalletModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-background font-sans antialiased text-foreground">
      <TopNav 
        onConnectWallet={() => setWalletModalOpen(true)} 
        isWalletConnected={!!user}
        walletAddress={user?.wallet}
      />
      <main>
        <LandingHero />
      </main>
      <WalletModal 
        open={walletModalOpen} 
        onOpenChange={setWalletModalOpen} 
        onConnect={handleWalletConnect} 
      />
    </div>
  );
}
